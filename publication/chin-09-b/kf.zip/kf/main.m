%-------------------------------------------------------------------------
% Robust Fitting of Multiple Structures: The Statistical Learning Approach
%-------------------------------------------------------------------------
% The demo code in this package implements the robust fitting technique
% proposed in:
% T.-J. Chin, H. Wang and D. Suter
% Robust Fitting of Multiple Structures: The Statistical Learning Approach
% In Proc. Int. Conf. on Computer Vision 2009, Kyoto, Japan
%
% Copyright (c) 2009 Tat-Jun Chin
% School of Computer Science, The University of Adelaide, South Australia
% http://www.cs.adelaide.edu.au/~tjchin
%
% The program is free for non-commercial academic use. Any commercial use
% is strictly prohibited without the author's consent. Please acknowledge
% the authors by citing the above paper in any academic publications that
% have made use of this package or part of it.
%
% If you encounter any problems or questions please email the author.
% 
% This program makes use of the Matlab GMM fitting package GMM-GMR-v1.2 by
% Sylvain Calinon (http://www.calinon.ch/sourcecodes.php).

%------------------------
% User selects data type.
%------------------------
type = input('Type of data? [1 One line] [2 Roof] [3 Z] [4 W] [5 Star] >');

%---------------
% Generate data.
%---------------
points_per_line    = 100;
number_of_outliers = 200;
maximum_data_size  = 700;
inlier_noise_scale = 0.01;
data = genData(type,type*points_per_line,...
               inlier_noise_scale,...
               min(maximum_data_size-type*points_per_line,...
               number_of_outliers));

%----------------------
% Compile required dll.
%----------------------
if (exist('computeKernelMatrix')~=3)
    mex computeKernelMatrix.c
end

%-----------------------------------------
% Sample hypotheses and compute residuals.
%-----------------------------------------
[ par res inx ] = randomSampling(data,1000);

%---------------------------------
% Compute Ordered Residual Kernel.
%---------------------------------
[ K ] = computeORK(data,res,20,1);

%-----------------
% Outlier removal.
%-----------------
[ keepInx, ptsNorm, th, gmm ] = removeOutliers(K,1);

%--------------------------------
% (Over)cluster remaining points.
%--------------------------------
[ idx centNum ] = clusterInliers(K(keepInx,keepInx));

%-----------------
% Model selection.
%-----------------
[ st his ] = modelSelect(idx,par,res(keepInx,:));

%------
% Show.
%------
figure;    
subplot(1,2,1);
plot(data(1,:),data(2,:),'b.');
title('Input data');
axis([0 1 0 1]);
subplot(1,2,2);
plot(data(1,:),data(2,:),'b.');
title(sprintf('Result: Found %d lines',length(st)));
axis([0 1 0 1]);
hold on;
for i=1:length(st)
    line_plot(st(i).hyp);
end