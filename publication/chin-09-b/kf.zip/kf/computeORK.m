function [ K ] = computeORK(data,res,win,combo)
%[ K ] = computeORK(data,res,win,combo)
%Compute the Ordered Residual Kernel (ORK).
%
%data (dim x n)
%    Input data, dim = input space dimension, n = number of data points.
%res (n x M)
%    Residual values, M = number of hypotheses.
%win
%    Step size.
%combo
%    [OPTIONAL] When set to 1 will combine ORK with the Gaussian kernel.
%K (n x n)
%    The resulting kernel matrix.
%
%Copyright (c) 2009 Tat-Jun Chin
%School of Computer Science, The University of Adelaide, South Australia
%http://www.cs.adelaide.edu.au/~tjchin
%
%This program is part of the package that implements the paper:
%T.-J. Chin, H. Wang and D. Suter
%Robust Fitting of Multiple Structures: The Statistical Learning Approach
%In Proc. Int. Conf. on Computer Vision 2009, Kyoto, Japan
%
%The program is free for non-commercial academic use. Any commercial use
%is strictly prohibited without the author's consent. Please acknowledge
%the authors by citing the above paper in any academic publications that
%have made use of this program or part of it.

%-----------------------------------------
% Sort all distances and keep the indices.
%-----------------------------------------
resinx = zeros(size(res));
for i=1:size(res,1)
    [ x resinx(i,:) ] = sort(res(i,:));
end

%--------------
% Evaluate ORK.
%--------------
x = win:win:size(res,2);
y = win*ones(1,size(res,2)/win);
weight = exp(-((x - y).^2)./( 2*(win^2)) );
weight = weight./sum(weight);   % Normalize the weights beforehand.
fprintf('Computing Ordered Residual Kernel...');
tic;
K = computeKernelMatrix(resinx',resinx',2,[ win weight ]);
fprintf('done (%fs)\n',toc);

%--------------------------------------------
% OPTIONAL: Combine with the Gaussian kernel.
%--------------------------------------------
if (nargin==4)&&(combo==1)
    
    % Compute average nearest neighbour distance.
    [ dd ] = pdist(data','euclidean');
    dis = squareform(dd).^2;
    sdis = sort(dis);
    sig = sqrt(mean(sdis(2,:)));    

    % Combine with the Gaussian kernel.
    K2 = computeKernelMatrix(data,data,1,sig);
    K = K + K2;
end

end