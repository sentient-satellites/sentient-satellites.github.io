/*
 * Copyright (c) 2009 Tat-Jun Chin
 * School of Computer Science, The University of Adelaide, South Australia
 * http://www.cs.adelaide.edu.au/~tjchin
 *
 * This program is part of the package that implements the paper:
 * T.-J. Chin, H. Wang and D. Suter
 * Robust Fitting of Multiple Structures: The Statistical Learning Approach
 * In Proc. Int. Conf. on Computer Vision 2009, Kyoto, Japan
 *
 * The program is free for non-commercial academic use. Any commercial use
 * is strictly prohibited without the author's consent. Please acknowledge
 * the authors by citing the above paper in any academic publications that
 * have made use of this program or part of it.
 */

#include "mex.h"
#include "math.h"
#include "time.h"

double myKernel(double *x, double *z, int pix, int type, double *param, double *accum,int *tab);

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    /* Input/output variables.*/
    double *K;
    double *A1;
    double *A2;
    double *KTYPE,*KPARAM;
  
    /* Intermediate variables.*/
    int m1,n1,m2,n2;
    int i,j;
    double *accum;
    int *symTab;
  
    /* Check for proper number of arguments. */    
    if (nrhs != 4)
    {
        mexErrMsgTxt("Four inputs required.");
    }
    else if (nlhs > 2)
    {
        mexErrMsgTxt("Too many output arguments.");
    }
  
    /* Assign pointers to inputs.*/
    A1 = mxGetPr(prhs[0]);
    A2 = mxGetPr(prhs[1]);
    KTYPE = mxGetPr(prhs[2]);
    KPARAM = mxGetPr(prhs[3]);
  
    /* Get sizes of input matrices.*/
    m1 = mxGetM(prhs[0]);
    n1 = mxGetN(prhs[0]);
    m2 = mxGetM(prhs[1]);
    n2 = mxGetN(prhs[1]);
  
    /* Create matrix for the return argument. */
    plhs[0] = mxCreateDoubleMatrix(n1,n2,mxREAL); 
    plhs[1] = mxCreateDoubleMatrix(1,1,mxREAL);
  
    /* Assign pointers to output.*/
    K = mxGetPr(plhs[0]);  
  
    /* Allocate space for symbol tables (required for Ordered Residual Kernel).*/
    symTab = (int *)calloc(2*m1,sizeof(int));
    if ((int)KTYPE[0]==2)
    {
        accum = (double *)calloc((double)m1/KPARAM[0],sizeof(double));
    }
    else
    {
        accum = (double *)calloc(1,sizeof(double));
    }
  
    /* Start computations.*/
    for(j=0;j<n1;j++)
    {
        for(i=0;i<n2;i++)
        {
            K[ j + i*n1 ] = myKernel( A1+j*m1, A2+i*m2, m1, (int)(KTYPE[0]), KPARAM, accum, symTab);         
        }
    }
  
    /* Housekeeping.*/
    free(symTab);
    free(accum);
}

double myKernel(double *x, double *z, int pix, int type, double *param, double *accum,int *tab)
{   
    int n,h;
    double keval,norm;    
    
    switch(type)
    {
        case 1:
            /* Gaussian Kernel.*/
            accum[0] = 0;
            for(n=0;n<pix;n++)
            {
                accum[0] = accum[0] + (x[n] - z[n])*(x[n] - z[n]);
            }
            keval = exp( (-1)*accum[0]/(2*param[0]*param[0]) );
            break;
        case 2:
            /* Ordered Residual Kernel.*/            
            /* Supplied weights must be normalized beforehand.*/
            
            /* Initialize symbol table.*/
            for(n=0;n<2*pix;n++)
            {
                tab[n] = -1;
            }
            
            /* Fill the tables.*/
            h = -1;
            for(n=0;n<pix;n++)
            {   
                if (fmod((double)n,param[0])==0)
                {
                    h++;
                }
                if (param[h+1]<0.01)
                {
                    break;
                }
                tab[(int)x[n]-1] = h;
                tab[pix+(int)z[n]-1] = h;
            }
            
            /* Intersect.*/
            for(n=0;n<h;n++)            
            {
                accum[n] = 0;
            }
            for(n=0;n<pix;n++)
            {
                if ((tab[n]<0)||(tab[pix+n]<0))
                {
                    continue;
                }
                accum[((tab[n] <= tab[pix+n])? tab[pix+n]:tab[n])]++;
            }
            
            /* Normalized intersection.*/
            for(n=0;n<h;n++)
            {
                accum[n] = accum[n]/((n+1)*param[0]);
            }
            
            /* Compute response.*/
            keval = 0;
            for(n=0;n<h;n++)
            {
                keval += param[n+1]*accum[n];
            }
            keval = keval;
            
            break;
    }    
    return(keval); 
}
