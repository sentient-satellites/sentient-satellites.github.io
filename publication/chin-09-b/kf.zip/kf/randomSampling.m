function [ par res inx ] = randomSampling(data,M)
% [ par res inx ] = randomSampling(data,M)
% Randomly sample model hypotheses and compute residuals.
%
% data (dim x n)
%    Input data, dim = dimension of input space, n = number of data.
% M
%    Number of hypotheses.
% par (numpar x M)
%    Random hypotheses generated, numpar = number of parameters in the model.
% res (n x M)
%    Residuals to generated hypotheses.
% inx (psize x M)
%    Indices of points used to generate random hypotheses, psize = size of p-subset.
%
%Copyright (c) 2009 Tat-Jun Chin
%School of Computer Science, The University of Adelaide, South Australia
%http://www.cs.adelaide.edu.au/~tjchin
%
%This program is part of the package that implements the paper:
%T.-J. Chin, H. Wang and D. Suter
%Robust Fitting of Multiple Structures: The Statistical Learning Approach
%In Proc. Int. Conf. on Computer Vision 2009, Kyoto, Japan
%
%The program is free for non-commercial academic use. Any commercial use
%is strictly prohibited without the author's consent. Please acknowledge
%the authors by citing the above paper in any academic publications that
%have made use of this program or part of it.

%---------------------------
% Model specific parameters.
%---------------------------
addpath('model_specific');
fitfn = @line_fit;
resfn = @line_res;
degenfn = @line_degen;
psize = 2;
numpar = 3;    

%----------------------------
% Random hypothesis sampling.
%----------------------------

n = size(data,2);
par = zeros(numpar,M);
res = zeros(n,M);
inx = zeros(psize,M);
degenmax = 10;

fprintf('Sampling %d hypotheses...',M);
tic;
for m=1:M    

    % Sample.
    degencnt = 0;
    isdegen = 1;
    while (isdegen==1)&&(degencnt<=degenmax)
        
        % Increment degeneracy count.
        degencnt = degencnt + 1;

        % Pick a p-subset.
        [ pinx ] = randsample(n,psize);
        psub = data(:,pinx);
        
        % Check for degeneracy.        
        isdegen = feval(degenfn,psub);
    end
    
    % Fit the model on the p-subset.
    st = feval(fitfn,psub);
    
    % Compute residuals.
    ds = feval(resfn,st,data);
    
    % Store.
    par(:,m) = st;
    res(:,m) = ds;
    inx(:,m) = pinx;
    
end
fprintf('done (%fs)\n',toc);

end