function [ idx, k ] = clusterInliers(K)
%[ idx k ] = clusterInliers(K)
%Cluster input data via spectral clustering.
%
%K (n x n)
%    ORK kernel matrix of data to be clustered.
%idx (n x 1)
%    Index of data clustering.
%k
%    Number of clusters.
%
%Copyright (c) 2009 Tat-Jun Chin
%School of Computer Science, The University of Adelaide, South Australia
%http://www.cs.adelaide.edu.au/~tjchin
%
%This program is part of the package that implements the paper:
%T.-J. Chin, H. Wang and D. Suter
%Robust Fitting of Multiple Structures: The Statistical Learning Approach
%In Proc. Int. Conf. on Computer Vision 2009, Kyoto, Japan
%
%The program is free for non-commercial academic use. Any commercial use
%is strictly prohibited without the author's consent. Please acknowledge
%the authors by citing the above paper in any academic publications that
%have made use of this program or part of it.

% Eigenspectrum threshold (the higher this is, the more clusters you get).
ccSTh = 1.0e-3;

%---------------------------------------
% Reduce dimensionality with Kernel PCA.
%---------------------------------------

% Centre the kernel matrix.
nu = eye(size(K,1)) - (1/size(K,1))*ones(size(K,1),size(K,1));
K = nu'*K*nu;

% Enforce symmetry.
Ku = triu(K,1);
Kl = Ku';
Kd = diag(diag(K));
K = Ku + Kd + Kl;

% Decompose kernel matrix.
[ E V ] = eig(K);
E = fliplr(E);
V = flipud(fliplr(V));

% The points to work with for clustering.
x = E(:,1:6)';

%---------------------
% Spectral clustering.
%---------------------

% Compute average nearest neighbour distance.
[ dd ] = pdist(x','euclidean');
dis = squareform(dd).^2;
sdis = sort(dis);
sig = sqrt(mean(sdis(2,:)));    

% Get affinity matrix.
W = computeKernelMatrix(x,x,1,sig);

% Degree matrix.
D = diag(ones(1,size(W,2))*W);

% Unnormalized graph Laplacian matrix.
L = D - W;

% Eigendecomposition.
[ U S ] = eig(L);

% Threshold to determine the number of clusters.
sS = 100*diag(S)./sum(diag(S));
csS = sS'*triu(ones(length(sS),length(sS)),0);

% Impose a maximum of 10 clusters--- this is purely for computational
% efficiency. Removing this shouldn't affect the results.
k = min(sum(csS<ccSTh),10);

% Perform k-means.
fprintf('Clustering inliers...');
tic;
warning('off');
[ idx cent ] = kmeans(x',k,'replicates',50);
warning('on');
fprintf('done (%fs)\n',toc);

end