function [ stret his ] = modelSelect(idx,par,res)
%[ stret his ] = modelSelect(idx,par,res)
%Model selection to detect the optimal number of lines.
%
%idx (n x 1)
%    Cluster index of n input points.
%par (numpar x M)
%    Parameters of sampled model hypotheses, numpar = number of model parameters, M = number of hypotheses.
%res (n x M)
%    Residual values of n input points as computed to par.
%
%Copyright (c) 2009 Tat-Jun Chin
%School of Computer Science, The University of Adelaide, South Australia
%http://www.cs.adelaide.edu.au/~tjchin
%
%This program is part of the package that implements the paper:
%T.-J. Chin, H. Wang and D. Suter
%Robust Fitting of Multiple Structures: The Statistical Learning Approach
%In Proc. Int. Conf. on Computer Vision 2009, Kyoto, Japan
%
%The program is free for non-commercial academic use. Any commercial use
%is strictly prohibited without the author's consent. Please acknowledge
%the authors by citing the above paper in any academic publications that
%have made use of this program or part of it.

% Initial number of structures.
k = length(unique(idx));

% Storage for the clusters.
st = repmat(struct('idx',[]),k,1);
for i=1:k
    st(i,1).idx = idx==i;
end

% Fit structures.
[ st ] = fitStructure(st,par,res);

% Save model selection cost.
sct = repmat(struct('st',[],'cost',[]),length(st),1);

% Start greedy merging operation.
fprintf('Performing model selection...');
tic;
mincost = modelSelectCost(st);
for m=length(st):-1:1

    % Compute model selection cost.
    sct(m).cost = mincost;
    sct(m).st = st;
    
    % Stopping criterion (boundary).
    if (m==1)
        break;
    end
    
    % Test merging of all possible pairs.
    costlist = zeros(nchoosek(length(st),2),1);
    pair = zeros(nchoosek(length(st),2),2);
    t = 0;
    for i=1:length(st);
        for j=(i+1):length(st)
            sttest = st;
            sttest(i).idx = or(sttest(i).idx,sttest(j).idx);
            sttest(j) = [];
            [ sttest ] = fitStructure(sttest,par,res);
            t = t + 1;
            costlist(t) = modelSelectCost(sttest);
            pair(t,1) = i;
            pair(t,2) = j;
        end
    end    

    % Merge the pair which causes the largest decrease.
    [ mincost mininx ] = min(costlist);    
    st(pair(mininx,1)).idx = or(st(pair(mininx,1)).idx,st(pair(mininx,2)).idx);
    st(pair(mininx,2)) = [];
    
    % Re-estimate model parameters.
    [ st ] = fitStructure(st,par,res);

end
fprintf('done (%fs)\n',toc);

[ mincost mininx ] = min([sct.cost]);
stret = sct(mininx).st;
his = [ sct.cost ];

end

function [ so ] = fitStructure(si,par,res)
% Fit the generic model onto each cluster using LMedS.

% Number of clusters.
k = length(si);

% Output variable.
so = repmat(struct('idx',[],'n',0,'hyp',0,'res',[],'sig',[]),k,1);

% Compute cluster hypothesis using LMedS.
for i=1:k
    so(i).idx = si(i).idx;
    so(i).n = sum(so(i).idx);
    [ minMedRes minInx ] = min(median(res(so(i).idx,:)));
    so(i).hyp = par(:,minInx);
    so(i).res = res(so(i).idx,minInx);
    so(i).sig = sqrt(sum(so(i).res.^2)/so(i).n);
end

end

function [ cost ] = modelSelectCost(st)
% Implements the Geometrically Robust Information Criterion (GRIC).
% See [ 2002, Torr, Bayesian model estimation and selection
% for epipolar geometry and generic manifold fitting ] (equation 43).

% Parameters to determine relative importance between goodness-of-fit
% and model complexity.
alpha = [ 1 20 ];

% Log-likelihood of dataset.
loglike = 0;
for i=1:length(st)
    loglike = loglike + (st(i).n)*(log(1/(sqrt(2*pi)*st(i).sig))) - sum((st(i).res.^2)./(2*st(i).sig^2));
end

% Size of data.
N = sum([st.n]);

% Dimension of manifold.
d = 1;

% Number of parameters.
p = length(st)*2;

% Dimension of the data.
R = 2;

cost = alpha(1)*(-2*loglike) + alpha(2)*(N*d*log(R) + p*log(R*N));

end