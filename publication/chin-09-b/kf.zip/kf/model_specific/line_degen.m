function r = line_degen(X)

r = any(pdist(X) < eps);
    
end