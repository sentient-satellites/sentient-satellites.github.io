function [ keepInx, ptsNorm, th, gmm ] = removeOutliers(K,method)
%[ keepInx ptsNorm th gmm ] = removeOutliers(K)
%Remove outliers via vector norm thresholding.
%
%K (n x n)
%    Ordered Residual Kernel of input data, n = number of points.
%method
%    [OPTIONAL] Thresholding computation method. 1- Hard thresholding (default), 2- Two-mode GMM fitting.
%keepInx (1 x n)
%    Index of input points to keep.
%ptsNorm (1 x n)
%    Vector norms in principal subspace.
%th
%    Norm threshold.
%gmm
%    Structure containing two-component gmm fitted onto norm histogram.
%
%Copyright (c) 2009 Tat-Jun Chin
%School of Computer Science, The University of Adelaide, South Australia
%http://www.cs.adelaide.edu.au/~tjchin
%
%This program is part of the package that implements the paper:
%T.-J. Chin, H. Wang and D. Suter
%Robust Fitting of Multiple Structures: The Statistical Learning Approach
%In Proc. Int. Conf. on Computer Vision 2009, Kyoto, Japan
%
%The program is free for non-commercial academic use. Any commercial use
%is strictly prohibited without the author's consent. Please acknowledge
%the authors by citing the above paper in any academic publications that
%have made use of this program or part of it.

% Compute principal subspace.
[ U S ] = eig(K);
U = fliplr(U);
S = flipud(fliplr(S));

% Take first-6 significant dimensions only.
pts = U(:,1:6)';

% Evaluate norms in the subspace.
ptsNorm = sqrt(sum(pts.^2));

% Fit two-component GMM.
fprintf('Fitting dual-mode GMM for outlier removal...');
tic;
[ priors mu var ] = gmmWrapper(ptsNorm,[0.5 0.5],[min(ptsNorm) max(ptsNorm)],[max(ptsNorm)/10 max(ptsNorm)/10]);
fprintf('done (%fs)\n',toc);

% Compute threshold.
sig = sqrt(var);
mu = [ mu mean(ptsNorm) ];
sig = [ sig std(ptsNorm) ];
priors = [ priors 0 ];

if (nargin==1)||((nargin==2)&&(method==1))
    
    % Hard thresholding.
    th = 0.3*max(ptsNorm);
    
elseif ((nargin==2)&&(method==2))

    % Use GMM fitting result.
    th = 0.5*(mu(1)+mu(2));
    if priors(1)>0.8
        th = mu(1) + (priors(2)/0.2)*(th-mu(1));
    end
    
end

% Remove low-norm points.
keepInx = ptsNorm>=th;
gmm.priors = priors;
gmm.mu = mu;
gmm.sig = sig;

end