function [ data ] = genData(type,inum,isig,onum)
%[ data ] = genData(type,inum,isig,onum)
%Generates 2D synthetic data.
%type: Type of data.
%      1- One line
%      2- Roof
%      3- Z
%      4- W
%      5- Star
%inum: Number of inlier points (divided evenly among structures).
%isig: Sigma of Gaussian noise for inlier points.
%onum: Number of outlier points.
%data: Resulting data.
%
%Copyright (c) 2009 Tat-Jun Chin
%School of Computer Science, The University of Adelaide, South Australia
%http://www.cs.adelaide.edu.au/~tjchin
%
%This program is part of the package that implements the paper:
%T.-J. Chin, H. Wang and D. Suter
%Robust Fitting of Multiple Structures: The Statistical Learning Approach
%In Proc. Int. Conf. on Computer Vision 2009, Kyoto, Japan
%
%The program is free for non-commercial academic use. Any commercial use
%is strictly prohibited without the author's consent. Please acknowledge
%the authors by citing the above paper in any academic publications that
%have made use of this program or part of it.

switch type
    case 1
        generateInliers = @generateOneLine;
    case 2
        generateInliers = @generateRoof;
    case 3
        generateInliers = @generateZorro;
    case 4
        generateInliers = @generateW;
    case 5
        generateInliers = @generateStar;
end

inliers = generateInliers(inum,isig);
outliers = generateOutliers(onum);

data = [ inliers outliers ];

end

function [ pts ] = generateOneLine(inum,isig)

m = 0.5;
c = 0.2;

X = rand(1,inum);
Y = m*X + c*ones(1,inum) + isig*randn(1,inum);

pts = [ X ; Y ];

end

function [ pts ] = generateRoof(inum,isig)

m1 = 1.5;
c1 = 0.1;

X1 = 0.5*rand(1,round(inum/2));
Y1 = m1*X1 + c1*ones(1,length(X1)) + isig*randn(1,length(X1));

m2 = -1.5;
c2 = 1.6;

X2 = 0.5*rand(1,round(inum/2)) + 0.5;
Y2 = m2*X2 + c2*ones(1,length(X2)) + isig*randn(1,length(X2));

pts = [ X1 X2 ; Y1 Y2 ];

end

function [ pts ] = generateW(inum,isig)

X1 = 0.25*rand(1,round(inum/4));
X2 = 0.25*rand(1,round(inum/4)) + 0.75;
X3 = 0.25*rand(1,round(inum/4)) + 0.25;
X4 = 0.25*rand(1,round(inum/4)) + 0.50;

m1 = -4;
c1 = 1;

m2 = 4;
c2 = -3;

m3 = 4;
c3 = -1;

m4 = -4;
c4 = 3;

Y1 = m1*X1 + c1*ones(1,length(X1)) + isig*randn(1,length(X1));
Y2 = m2*X2 + c2*ones(1,length(X2)) + isig*randn(1,length(X2));
Y3 = m3*X3 + c3*ones(1,length(X3)) + isig*randn(1,length(X3));
Y4 = m4*X4 + c4*ones(1,length(X4)) + isig*randn(1,length(X4));

pts = [ X1 X2 X3 X4 ; Y1 Y2 Y3 Y4 ];

end

function [ pts ] = generateZorro(inum,isig)

X1 = rand(1,round(inum/3));
X2 = rand(1,round(inum/3));
X3 = rand(1,round(inum/3));

m2 = 0.6;
c2 = 0.2;

Y1 = 0.2*ones(1,length(X1)) + isig*randn(1,length(X1));
Y2 = m2*X2 + c2*ones(1,length(X2)) + isig*randn(1,length(X2));
Y3 = 0.8*ones(1,length(X1)) + isig*randn(1,length(X1));

pts = [ X1 X2 X3 ; Y1 Y2 Y3 ];

end

function [ pts ] = generateStar(inum,isig)

X1 = rand(1,round(inum/5));
X2 = 0.6*rand(1,round(inum/5));
X3 = 0.6*ones(1,round(inum/5)) + isig*randn(1,round(inum/5));
X4 = rand(1,round(inum/5));
X5 = 0.6*rand(1,round(inum/5));

m1 = 0.3;
c1 = 0.2;
m2 = 0.8/0.6;
c2 = 0.2;
m3 = 0;
c3 = 0;
m4 = -0.3;
c4 = 0.8;
m5 = -0.8/0.6;
c5 = 0.8;

Y1 = m1*X1 + c1*ones(1,length(X1)) + isig*randn(1,length(X1));
Y2 = m2*X2 + c2*ones(1,length(X2)) + isig*randn(1,length(X2));
Y3 = rand(1,length(X3));
Y4 = m4*X4 + c4*ones(1,length(X4)) + isig*randn(1,length(X4));
Y5 = m5*X5 + c5*ones(1,length(X5)) + isig*randn(1,length(X5));

pts = [ X1 X2 X3 X4 X5 ; Y1 Y2 Y3 Y4 Y5 ];

end

function [ pts ] = generateOutliers(onum)

X = rand(1,onum);
Y = rand(1,onum);

pts = [ X ; Y ];

end