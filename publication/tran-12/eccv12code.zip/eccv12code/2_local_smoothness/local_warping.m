function p_chk = local_warping(q, Qp, Qq, ir, C, E, ZtZ)

% Normalize features.
n = size(Qq,2);
[ Qq_norm T ] = unit_normalization(Qq);

% Compute the kernelization matrix (size nx(l+3)).
W = GTPSW_TPS_kernelize(C,Qq_norm');

% Compute the parameter matrix (size lx2).
A = W*E;
L = (A'*A + n*ir^2*ZtZ)\A'*Qp';

% Compute the kernelization vector (size 1x(l+3)).
q_norm = T*[ q; 1 ];
lp = GTPSW_TPS_kernelize(C,q_norm(1:2)');

% Compute the warping point.
p_chk = L'*E'*lp;

end