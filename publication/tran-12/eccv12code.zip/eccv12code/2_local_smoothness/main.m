% Add path.
addpath('GTPSW');

% Parameters.
dTH = 17.5;     % Outlier threshold.
ir = 10^-4;     % Smoothness coefficient.

% Load data.
load('../data/tshirt');

% Start timer.
tic;

% Prepare for local warping.
l = 9;
[ X Y ] = meshgrid(linspace(0,1,sqrt(l)),linspace(0,1,sqrt(l)));
C = [ reshape(X,1,l)' reshape(Y,1,l)' ];
E = GTPSW_TPS_compute_FDPMat(C,[],ir); 
ZtZ = 8*pi*E(1:l,:);

Cp = data(1:2,:);
Cq = data(4:5,:);

% Compute the distance by local warping.
T = delaunay(Cp');
n = size(data,2);
d = zeros(1,n);
for i=1:n
    p = Cp(:,i);
    q = Cq(:,i);
    [ rows cols ] = find(T==i);
    triangles = T(rows,:);
    neighbours = setdiff(unique(triangles),i);    
    Qp = Cp(:,neighbours);
    Qq = Cq(:,neighbours);    
    p_chk = local_warping(q,Qp,Qq,ir,C,E,ZtZ);    
    d(i) = sqrt(sum((p - p_chk).^2));
end

% Select the initial set of inliers.
inliers = find(d < dTH);
outliers = find(d >= dTH);
Gp = Cp(:,inliers);
Gq = Cq(:,inliers);

% Iterative to add more inliers.
while (1)    
    grow = 0;
    extra = [];
    m = length(outliers);    
    for k=1:m    
        outindex = outliers(k);
        p = Cp(:,outindex);
        q = Cq(:,outindex);
        Gpk = [ Gp p ];
        Gqk = [ Gq q ];              
        pkindex = size(Gpk,2);
        T_str = delaunay(Gpk');              
        [ rows cols ] = find(T_str==pkindex);
        triangles = T_str(rows,:);
        neighbours = setdiff(unique(triangles),pkindex);    
        Qp = Gpk(:,neighbours);
        Qq = Gqk(:,neighbours);    
        p_chk = local_warping(q,Qp,Qq,ir,C,E,ZtZ);    
        d = sqrt(sum((p - p_chk).^2));

        if (d < dTH)            
            Gp = Gpk;
            Gq = Gqk;   
            extra = [ extra outindex ];
            grow = 1;
        end
    end

    if (~grow)
        break;
    else
        inliers = [ inliers extra ];
        outliers = setdiff(outliers, extra);
    end
end
            
% Convert to indexes.
inlindex = ismember(1:n,inliers);

% Stop timer.
tim = toc;

% Compute error.
n = size(data,2);
tp = sum(label==1&inlindex==1);
fp = sum(label-inlindex>0);
tn = sum(label==0&inlindex==0);
fn = sum(label-inlindex<0);    
tpr = tp/(tp+fn);
fpr = fp/(fp+tn);
err = fp+fn;

% Show result.
figure;
imshow([[ img1 ; zeros(max(0,size(img2,1)-size(img1,1)),size(img1,2)) ] [ img2 ; zeros(max(0,size(img1,1)-size(img2,1)),size(img2,2)) ] ]);
title(sprintf('Running Time = %.2fs - True Positive Rate = %.2f - False Positive Rate = %.2f - Labelling Error = %d.\n',tim,tpr,fpr,err));
hold on;
for i=1:n
    if (inlindex(i)==1)
        plot(data(1,i),data(2,i),'go','LineWidth',2);
        plot(data(4,i)+size(img1,2),data(5,i),'go','LineWidth',2);
        plot([data(1,i) data(4,i)+size(img1,2)],[data(2,i) data(5,i)],'g-','LineWidth',1);
    else
        plot(data(1,i),data(2,i),'ro','LineWidth',2);
        plot(data(4,i)+size(img1,2),data(5,i),'ro','LineWidth',2);
        plot([data(1,i) data(4,i)+size(img1,2)],[data(2,i) data(5,i)],'r-','LineWidth',1);
    end
end