function [ Qq_norm T ] = unit_normalization(Qq)

% Find the minimum value and scale of coordinates.
c = min(Qq,[],2);
s = max(Qq,[],2)-c;

% Normalize coordinates to [0,1]x[0,1].
Qq_norm(1,:) = (Qq(1,:)-c(1))./s(1);
Qq_norm(2,:) = (Qq(2,:)-c(2))./s(2);

% Compute the transformation matrix.
T = [ 1/s(1)    0   -c(1)/s(1); 
        0   1/s(2)  -c(2)/s(2); 
        0       0       1       ];
    
end

