% This function goes with the GTPSW (Generalized Thin-Plate Spline Warps) package.
% Please cite my paper on this topic that you shall find on my web page if
% you use this package. Adrien Bartoli.

function [E,oK] = GTPSW_TPS_compute_FDPMat(P,K,ir,st)
% E = GTPSW_TPS_compute_FDPMat(P,K,ir,st)
%
% Computes the Feature-Driven Parameterization Matrix (FDPMat).
%
% This file is part of the GTPSW package by Adrien Bartoli.
%
% Inputs:
%
%  - P [(l x 2) matrix]
%   The source centres.
%
%  - (opt) K [(l x l) matrix]
%   The KIDMat.
%   Default: recomputed using GTPSW_TPS_compute_KIDMat.
%   Note: use [] for the default value.
%
%  - (opt) ir [scalar]
%   The internal regularization parameter.
%   Default: ir = 10^-5.
%   Note: use [] for the default value.
%   Do not use if K is specified.
%
%  - (opt) st [scalar]
%   The squared stiffness parameter.
%   Default: st = 1.
%   Do not use if K is specified.
%
% Outputs:
%
%  - E [((l+3) x l) matrix]
%   The FDPMat.
%
%  - (opt) K [(l x l) matrix]
%   The KIDMat.

% inputs
if ~exist('K','var') || isempty(K)
    if ~exist('ir','var')
        K = GTPSW_TPS_compute_KIDMat(P);
    elseif ~exist('st','var')
        K = GTPSW_TPS_compute_KIDMat(P,ir);
    else        
        K = GTPSW_TPS_compute_KIDMat(P,ir,st);
    end;
end;

l = size(P,1);

Pt      = [ P ones(l,1) ];
invK    = inv(K);
T1      = Pt'*invK;
T2      = inv(T1*Pt)*T1;    % inv(Pt'*invK*Pt)*Pt'*invK 
E       = [ 
    invK*(eye(l)-Pt*T2)
    T2    
];

% outputs
if nargout > 1, oK = K; end;
