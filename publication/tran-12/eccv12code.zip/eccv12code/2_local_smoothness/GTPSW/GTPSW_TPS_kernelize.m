% This function goes with the GTPSW (Generalized Thin-Plate Spline Warps) package.
% Please cite my paper on this topic that you shall find on my web page if
% you use this package. Adrien Bartoli.

function [W,oD] = GTPSW_TPS_kernelize(P,Q,st)
% [W,oD] = GTPSW_TPS_kernelize(P,Q,st)
%
% Kernelize a set of data points wrt a set of source centres with the TPS
% kernel.
%
% This file is part of the GTPSW package by Adrien Bartoli.
%
% Inputs:
%
%  - P [(l x 2) matrix]
%   The source centres.
%
%  - Q [(m x 2) matrix]
%   The data point coordinates.
%
%  - (opt) st [scalar]
%   The squared stiffness parameter.
%   Default: st = 1.
%
% Outputs:
%
%  - W [(m x (l+3)) matrix] or (l+3)-column-vector
%   The kernelized data points.
%   A row corresponds to a point.
%
%  - (opt) D [(m x l) matrix]
%   The squared point-to-centre distance matrix.

% inputs
if ~exist('st','var'), st = 1; end;

l = size(P,1);
m = size(Q,1);

% computes the point-to-center squared distance matrix
D = (repmat(Q(:,1),1,l) - repmat(P(:,1)',m,1)).^2 + (repmat(Q(:,2),1,l) - repmat(P(:,2)',m,1)).^2;
%D = (repmat(P(:,1),1,m) - repmat(Q(:,1)',l,1)).^2 + (repmat(P(:,2),1,m) - repmat(Q(:,2)',l,1)).^2;

% rescales it to account for the stiffness parameter
D = D./st;

% kernelizes it
W = zeros(m,l);
nz = find(D>=eps);
W(nz) = D(nz).*log(D(nz))/2;

% appends the affine part
W = [ W Q ones(m,1) ];

if m == 1
    W = W';
end;

% optional outputs
if nargout > 1, oD = D; end;
