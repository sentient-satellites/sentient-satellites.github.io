% This function goes with the GTPSW (Generalized Thin-Plate Spline Warps) package.
% Please cite my paper on this topic that you shall find on my web page if
% you use this package. Adrien Bartoli.

function [K,oD] = GTPSW_TPS_compute_KIDMat(P,ir,st)
% [K,D] = GTPSW_TPS_compute_KIDMat(P,ir,st)
%
% Computes the Kernelized Intercentre Distance Matrix (KIDMat).
%
% This file is part of the GTPSW package by Adrien Bartoli.
%
% Inputs:
%
%  - P [(l x 2) matrix]
%   The source centres.
%
%  - (opt) ir [scalar]
%   The internal regularization parameter.
%   Default: ir = 10^-5.
%   Note: use [] for the default value.
%
%  - (opt) st [scalar]
%   The squared stiffness parameter.
%   Default: st = 1.
%
% Outputs:
%
%  - K [(l x l) matrix]
%   The KIDMat.
%
%  - (opt) D [(l x l) matrix]
%   The squared intercentre distance matrix.

% inputs
if ~exist('ir','var') || isempty(ir)
    ir = 10^-5;
end;
if ~exist('st','var'), st = 1; end;
    
l = size(P,1);

% computes the intercenter squared distance matrix
D = (repmat(P(:,1),1,l) - repmat(P(:,1)',l,1)).^2 + (repmat(P(:,2),1,l) - repmat(P(:,2)',l,1)).^2;

% rescales it to account for the stiffness parameter
D = D./st;

% kernelizes it
K = ir*eye(l);
nz = find(D>=eps);
K(nz) = D(nz).*log(D(nz))/2;

% outputs
if nargout > 1, oD = D; end;
