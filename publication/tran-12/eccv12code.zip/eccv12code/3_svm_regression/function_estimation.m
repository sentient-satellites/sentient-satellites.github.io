function [ g1 g2 ] = function_estimation(data, theta, eps_mse, eps_infl)
   
S = data';
n = size(S,1);

% Estimate correspondence functions.
X = S(:,1:2);
U_chk = S(:,4);
V_chk = S(:,5);    
g1 = svmtrain(U_chk, X, '-s 3 -t 2 -g 0.00000009765625 -c 512 -p 0.25 -q');
g2 = svmtrain(V_chk, X, '-s 3 -t 2 -g 0.00000009765625 -c 512 -p 0.25 -q');        
[ U_est U_acc U_prb ] = svmpredict(U_chk, X, g1);
[ V_est V_acc V_prb ] = svmpredict(V_chk, X, g2);       
e1 = U_est - U_chk;
e2 = V_est - V_chk;
sigma1 = sqrt(sum(e1.^2)/n);
sigma2 = sqrt(sum(e2.^2)/n);

% Iterative estimation.
while (1)

    % Select the influentials.
    idx = find(abs(e1) <= theta*sigma1 & abs(e2) <= theta*sigma2);                    
    n_new = length(idx);

    % Re-estimate correspondence functions.
    X = S(idx,1:2);
    U_chk = S(idx,4);
    V_chk = S(idx,5);            
    g1 = svmtrain(U_chk, X, '-s 3 -t 2 -g 0.00000009765625 -c 512 -p 0.25 -q');
    g2 = svmtrain(V_chk, X, '-s 3 -t 2 -g 0.00000009765625 -c 512 -p 0.25 -q');       
    [ U_est U_acc U_prb] = svmpredict(U_chk, X, g1);
    [ V_est V_acc V_prb] = svmpredict(V_chk, X, g2);            
    e1 = U_est - U_chk;
    e2 = V_est - V_chk;    
    sigma1_new = sqrt(sum(e1.^2)/n_new);
    sigma2_new = sqrt(sum(e2.^2)/n_new);    

    % Determine the mean squared error and the influence.
    mse = sum(e1.^2 + e2.^2)/n_new;    
    infl1 = (sigma1^2 - sigma1_new^2)/sigma1^2;
    infl2 = (sigma2^2 - sigma2_new^2)/sigma2^2;

    fprintf('MSE = %.4f ***** INFL1 = %.4f ***** INFL2 = %.4f.\n', mse, infl1, infl2);    

    % Check for stopping iterative estimation.
    if ((mse <= eps_mse) || (infl1 <= eps_infl && infl2 <= eps_infl))                        
        break;
    else
        S = S(idx,:);
        n = size(S,1);          
        sigma1 = sigma1_new;
        sigma2 = sigma2_new;        
    end                  

end

end

