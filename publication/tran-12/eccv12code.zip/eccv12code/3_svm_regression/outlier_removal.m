function [ inliers ] = outlier_removal(data, g1, g2, xi)

S = data';
n = size(S,1);

% Outlier removal by correspondence functions.
X = S(:,1:2);
U_chk = S(:,4);
V_chk = S(:,5);  
[ U_est U_acc U_prb] = svmpredict(U_chk, X, g1);
[ V_est V_acc V_prb] = svmpredict(V_chk, X, g2);        
e1 = U_est - U_chk;
e2 = V_est - V_chk;
sigma1 = sqrt(sum(e1.^2)/n);
sigma2 = sqrt(sum(e2.^2)/n);
D_inv = [ 1/sigma1^2 0; 0 1/sigma2^2 ];
c = zeros(1,n);
for i=1:n
    c(i) = [ e1(i) e2(i) ]*D_inv*[ e1(i) e2(i) ]';
end
inliers = c<=xi;

end

