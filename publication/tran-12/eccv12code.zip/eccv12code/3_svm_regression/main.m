% Add path.
addpath('libsvm/matlab');

% Parameters.
xi = 2.7;           % Outlier threshold.
theta = 1.96;       % Influential threshold.
eps_infl = 0.3;     % INFL threshold.
eps_mse = 64;       % MSE threshold. 

% Load data.
load('../data/tshirt');
 
% Start timer.
tic;

% Estimate the first correspondence function f = {g1, g2}. 
[ g1 g2 ] = function_estimation(data, theta, eps_mse, eps_infl);

% Outlier removal by the first correspondence function f = {g1, g2}.
[ inliers1 ] = outlier_removal(data, g1, g2, xi);

% Estimate the second correspondence function f_chk = {g1_chk, g2_chk}.        
[ g1_chk g2_chk ] = function_estimation([data(4:6,:); data(1:3,:)], theta, eps_mse, eps_infl);

% Outlier removal by the second correspondence function f_chk = {g1_chk, g2_chk}.
[ inliers2 ] = outlier_removal([data(4:6,:); data(1:3,:)], g1_chk, g2_chk, xi);    

% Combine results.
inliers = inliers1|inliers2;       
    
% Stop timer.
tim = toc;

% Compute error.
n = size(data,2);
tp = sum(label==1&inliers==1);
fp = sum(label-inliers>0);
tn = sum(label==0&inliers==0);
fn = sum(label-inliers<0);    
tpr = tp/(tp+fn);
fpr = fp/(fp+tn);
err = fp+fn;

% Show result.
figure;
imshow([[ img1 ; zeros(max(0,size(img2,1)-size(img1,1)),size(img1,2)) ] [ img2 ; zeros(max(0,size(img1,1)-size(img2,1)),size(img2,2)) ] ]);
title(sprintf('Running Time = %.2fs - True Positive Rate = %.2f - False Positive Rate = %.2f - Labelling Error = %d.\n',tim,tpr,fpr,err));
hold on;
for i=1:n
    if (inliers(i)==1)
        plot(data(1,i),data(2,i),'go','LineWidth',2);
        plot(data(4,i)+size(img1,2),data(5,i),'go','LineWidth',2);
        plot([data(1,i) data(4,i)+size(img1,2)],[data(2,i) data(5,i)],'g-','LineWidth',1);
    else
        plot(data(1,i),data(2,i),'ro','LineWidth',2);
        plot(data(4,i)+size(img1,2),data(5,i),'ro','LineWidth',2);
        plot([data(1,i) data(4,i)+size(img1,2)],[data(2,i) data(5,i)],'r-','LineWidth',1);
    end
end