function T = compute_barycentric_coordinates(mesh_points, mesh_triangles, m0, triangle_index)

T = zeros(size(mesh_points,2),size(m0,2));

% Determine the differences from the points of the triangle
for i = 1:size(m0,2)    
    A = mesh_points(1,mesh_triangles(triangle_index(i),1)) - mesh_points(1,mesh_triangles(triangle_index(i),3)); % x1-x2
    B = mesh_points(1,mesh_triangles(triangle_index(i),2)) - mesh_points(1,mesh_triangles(triangle_index(i),3)); % x2-x3
    C = mesh_points(1,mesh_triangles(triangle_index(i),3)) - m0(1,i); % x3-x
    D = mesh_points(2,mesh_triangles(triangle_index(i),1)) - mesh_points(2,mesh_triangles(triangle_index(i),3)); % y1-y3
    E = mesh_points(2,mesh_triangles(triangle_index(i),2)) - mesh_points(2,mesh_triangles(triangle_index(i),3)); % y2-y3
    F = mesh_points(2,mesh_triangles(triangle_index(i),3)) - m0(2,i); % y3-y
    
    xi1 = (F*B - E*C)/(E*A - B*D);
    xi2 = (C*D - F*A)/(E*A - B*D);
    xi3 = 1 - xi1 - xi2;
    
    T(mesh_triangles(triangle_index(i),1),i) = xi1;
    T(mesh_triangles(triangle_index(i),2),i) = xi2;
    T(mesh_triangles(triangle_index(i),3),i) = xi3;    
end

end

