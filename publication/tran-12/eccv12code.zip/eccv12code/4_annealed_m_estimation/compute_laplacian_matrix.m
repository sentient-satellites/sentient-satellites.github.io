function [ triplets K ] = compute_laplacian_matrix(mesh_points, mesh_triangles, NROWS, NCOLS)

% Determine the neighbours of each point
neighbours = cell(0);
centeridx = 1;

% Identify potential center points of each triplets and identify their neighbours
eps = 10^-10;
for i = 1:size(mesh_points,2)       
    if (mesh_points(1,i)>=1 && mesh_points(2,i)>=1 && mesh_points(1,i)<=NCOLS+eps && mesh_points(2,i)<=NROWS+eps)
        [rows,cols] = find(mesh_triangles == i);
        triangles = mesh_triangles(rows,:);
        neighbours{centeridx,1} = i;
        neighbours{centeridx,2} = setdiff(unique(triangles(:)),i);
        centeridx = centeridx + 1;    
    end
end

% Identify each triplet of each center and add the triplets to list
triplets = zeros(0,3);
for i = 1:length(neighbours)
    ctr = neighbours{i,1};
    nbs = neighbours{i,2};
    nb_dirs = [];
    
    for k = 1:length(nbs)
        % This is the vector which point from the centre to the nb
        vec = mesh_points(:,nbs(k)) - mesh_points(:,ctr);
        % Classify this into a direction
        if vec(1)>0 && vec(2)==0 % E
            nb_dirs(k) = 1;
        elseif vec(1)>0 && vec(2)>0 % NE
            nb_dirs(k) = 2;
        elseif vec(1)<0 && vec(2)>0 % NW
            nb_dirs(k) = 3;
        elseif vec(1)<0 && vec(2)==0 % W
            nb_dirs(k) = 4;
        elseif vec(1)<0 && vec(2)<0 % SW
            nb_dirs(k) = 5;
        elseif vec(1)>0 && vec(2)<0 % SE
            nb_dirs(k) = 6;
        end               
    end

    % Check whether the opposite point is in the list
    if ~isempty(find(nb_dirs == 1)) && ~isempty(find(nb_dirs == 4))
        triplets = [triplets ; [nbs(find(nb_dirs == 1)) , ctr , nbs(find(nb_dirs == 4))] ];
    end
    if ~isempty(find(nb_dirs == 2)) && ~isempty(find(nb_dirs == 5))
        triplets = [triplets ; [nbs(find(nb_dirs == 2)) , ctr , nbs(find(nb_dirs == 5))] ];
    end
    if ~isempty(find(nb_dirs == 3)) && ~isempty(find(nb_dirs == 6))
        triplets = [triplets ; [nbs(find(nb_dirs == 3)) , ctr , nbs(find(nb_dirs == 6))] ];
    end 
end

K_slash = sparse(size(triplets,1),size(mesh_points,2));
for i = 1:size(triplets,1)
    K_slash(i,triplets(i,:)) = [-1 2 -1];
end

K = K_slash'*K_slash;