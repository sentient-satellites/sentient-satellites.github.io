function [ par res inx ] = prosac_sampling(data,M,qua_score)

%---------------------------
% Model specific parameters.
%---------------------------
addpath('model_specific');
fitfn = 'rigid_fit';
resfn = 'rigid_res';
degenfn = 'rigid_degen';
psize = 3;
numpar = 9;

%------------------------
% Check other parameters.
%------------------------
degenmax = 50;  % Max number of inner loop to avoid degeneracy.

%-----------------
% Prepare storage.
%-----------------
n = size(data,2);
par = zeros(numpar,M);
res = zeros(n,M);
inx = zeros(psize,M);

%-------------------
% Method parameters.
%-------------------
Tprime = 1;
T = M/nchoosek(n,psize);
sample_num = psize;

% Sort quality scores in non-ascending order.
[ foo qinx ] = sort(-qua_score);

%-----------------
% PROSAC Sampling.
%-----------------
for m=1:M
    
    if m == Tprime && sample_num < n
        sample_num = sample_num + 1;
        newT = T*sample_num/(sample_num-psize);
        Tprime = Tprime + ceil(newT - T);
        T = newT;
    end
    
    degencnt = 0;
    isdegen = 1;    
    while (isdegen==1)&&(degencnt<=degenmax)

        % Increment degeneracy count.
        degencnt = degencnt + 1;
    
        % Sample.
        if Tprime >= m
            inx1 = randsample(qinx(1:(sample_num-1)),(psize-1));
            inx2 = qinx(sample_num);
            pinx = [inx1,inx2];
        else
            pinx = randsample(qinx(1:sample_num),psize);
        end
        psub = data(:,pinx);
        
        % Check for degeneracy.
        isdegen = feval(degenfn,psub);       
    end   
    if (isdegen==1)
        error('Cannot find a valid p-subset!');
    end    
    
    % Fit model.
    st = feval(fitfn,psub);
    
    % Compute residuals.
    ds = feval(resfn,st,data);        

    % Store.
    par(:,m) = st;  
    res(:,m) = ds;    
    inx(:,m) = pinx;                
    
end

end