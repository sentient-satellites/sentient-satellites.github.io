function [points, triangles] = create_triangulated_mesh(x_stepsize, NROWS, NCOLS)

% Compute y_stepsize
y_stepsize = sqrt(3)/2*x_stepsize;

% Generate mesh points
points = zeros(2,0);
for y = 1:y_stepsize:NROWS+y_stepsize
    even = mod(y/y_stepsize,2);
    x = even*x_stepsize/2:x_stepsize:NCOLS+even*x_stepsize/2;
    points = [points [ x; y*ones(1,length(x)) ] ];
end

% Triangulate from mesh points
triangles = delaunay(points(1,:), points(2,:));

end