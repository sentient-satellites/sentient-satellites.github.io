-----------------------------------------------------------------------------
In Defence of RANSAC for Outlier Rejection in Deformable Surface Registration
-----------------------------------------------------------------------------

This package is the supplementary material for the following paper:

In Defence of RANSAC for Outlier Rejection in Deformable Surface Registration
Quoc-Huy Tran, Tat-Jun Chin, Gustavo Carneiro, Michael S. Brown, David Suter
In: European Conference on Computer Vision (ECCV), Florence, Italy, 2012.

Copyright (c) 2012 Quoc-Huy Tran and Tat-Jun Chin
School of Computer Science, The University of Adelaide, South Australia
http://www.cs.adelaide.edu.au/~{huy,tjchin}

The program is free for non-commercial academic use. Any commercial use
is strictly prohibited without the authors' consent. Please acknowledge
the authors by citing the above paper in any academic publications that
have made use of this package or part of it.

------------
Instructions
------------

* 'data': input data which is a .MAT file and consists of the following matrices:
    + img1: template image 
    + img2: input image
    + data: matches between template image and input image.
    + score: scores of matches
    + label: ground truth labels of matches (0: outliers, 1: inliers)

* '1_ransac_plane_fitting': implementation of our method using RANSAC plane fitting for outlier removal in deformable surface registration.
    Run the file 'main.m'. 

* '2_local_smoothness': our implementaion of outlier removal part of the paper [10]. Pizarro, D., Bartoli, A.: Feature-based deformable surface detection with self-occlusion reasoning. (IJCV 2011)
    Run the file 'main.m'.

* '3_svm_regression': our implementation of the paper [9]. Li, Z., Hu, Z.: Rejecting mismatches by correspondence function. (IJCV 2010)
    Download and install the libsvm library (link: http://www.csie.ntu.edu.tw/~cjlin/libsvm/)
    Run the file 'main.m'. 	

* '4_annealed_m_estimation': our implementation of the paper [3]. Zhu, J., Lyu, M.R.: Progressive finite newton approach to real-time nonrigid surface detection. (CVPR 2007)
    Run the file 'main.m'.
