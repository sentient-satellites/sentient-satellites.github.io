function [ par res inx ] = random_sampling(data,M)

%---------------------------
% Model specific parameters.
%---------------------------
fitfn = 'flat_fit';
resfn = 'flat_res';
degenfn = 'flat_degen';
psize = 3;
numpar = 3*size(data,1);

%------------------------
% Check other parameters.
%------------------------
degenmax = 10;  % Max number of inner loop to avoid degeneracy.

%-----------------
% Prepare storage.
%-----------------
n = size(data,2);
par = zeros(numpar,M);
res = zeros(n,M);
inx = zeros(psize,M);

%-----------------
% Random sampling.
%-----------------
for m=1:M    

    % Sample.
    degencnt = 0;
    isdegen = 1;
    while (isdegen==1)&&(degencnt<=degenmax)
        
        % Increment degeneracy count.
        degencnt = degencnt + 1;

        % Pick a p-subset.
        [ pinx ] = randsample(n,psize);
        psub = data(:,pinx);
        
        % Check for degeneracy.
        isdegen = feval(degenfn,psub);
    end
    if (isdegen==1)
        error('Cannot find a valid p-subset!');
    end    
    
    % Fit model.
    st = feval(fitfn,psub);
    
    % Compute residuals.
    ds = feval(resfn,st,data);
    
    % Store.
    par(:,m) = st;
    res(:,m) = ds;
    inx(:,m) = pinx;         
    
end

end