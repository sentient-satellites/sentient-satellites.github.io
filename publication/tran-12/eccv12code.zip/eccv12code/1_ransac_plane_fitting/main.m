% Add path.
addpath('model_specific');

% Parameters.
ransac_th = 0.3;        % RANSAC threshold.
ransac_iter = 100;      % RANSAC iterations.

% Load data.
load('../data/tshirt');

% Start timer.
tic;

% Normalise 2D points.
[ data_img1 T1 ] = normalise2dpts(data(1:3,:));
[ data_img2 T2 ] = normalise2dpts(data(4:6,:));
data_norm = [ data_img1 ; data_img2 ];

% Outlier removal using RANSAC.
A = [ data_norm(1:2,:) ; data_norm(4:5,:) ];
[ par res inx ] = random_sampling(A,ransac_iter);
[ ~, maxinx ] = max(sum(res<=ransac_th));
ininx = res(:,maxinx)<=ransac_th;   
[ U ~, ~, ] = svd(A*A');
P = U'*A;

% Stop timer.
tim = toc;

% Compute error.
n = size(data,2);
tp = sum(label==1&ininx'==1);
fp = sum(label-ininx'>0);
tn = sum(label==0&ininx'==0);
fn = sum(label-ininx'<0);
tpr = tp/(tp+fn);
fpr = fp/(fp+tn);
err = fp+fn;

% Show the plane.
figure;
title('Data after PCA');    
hold on;
plot3(P(1,~ininx),P(2,~ininx),P(3,~ininx),'ro','LineWidth',2);
plot3(P(1,ininx),P(2,ininx),P(3,ininx),'go','LineWidth',2);    
legend('Outliers by RANSAC Plane Fitting','Inliers by RANSAC Plane Fitting','Location','NorthEast');
grid on;
axis([ -4 4 -4 4 -5 5 ]);
view(-79.5,4);      
                           
% Show result.
figure;
imshow([[ img1 ; zeros(max(0,size(img2,1)-size(img1,1)),size(img1,2)) ] [ img2 ; zeros(max(0,size(img1,1)-size(img2,1)),size(img2,2)) ] ]);
title(sprintf('Running Time = %.2fs - True Positive Rate = %.2f - False Positive Rate = %.2f - Labelling Error = %d.\n',tim,tpr,fpr,err));
hold on;
for i=1:n
    if (ininx(i)==1)
        plot(data(1,i),data(2,i),'go','LineWidth',2);
        plot(data(4,i)+size(img1,2),data(5,i),'go','LineWidth',2);
        plot([data(1,i) data(4,i)+size(img1,2)],[data(2,i) data(5,i)],'g-','LineWidth',1);
    else
        plot(data(1,i),data(2,i),'ro','LineWidth',2);
        plot(data(4,i)+size(img1,2),data(5,i),'ro','LineWidth',2);
        plot([data(1,i) data(4,i)+size(img1,2)],[data(2,i) data(5,i)],'r-','LineWidth',1);
    end
end
