% -----------------------------------------
% generate random lines: a*x + b*y + c = 0.
% -----------------------------------------
function [ data, gnd ] = genLines(model_num,pts_per_model,isig,out_num)

gnd = zeros(3,model_num);

gen = 0;
while 1
    [ par ] = generateLineParam;

    if (gen==0)
        gen = gen + 1;
        gnd(:,gen) = par;
    else
        pardis = sqrt(sum((repmat(par,1,gen) - gnd(:,1:gen)).^2));        
        if min(pardis)>0.22
            gen = gen + 1;        
            gnd(:,gen) = par;
        end
    end
    if (gen == model_num)
        break;
    end
end    


% Generate data points.
inlier = zeros(2,model_num*pts_per_model);

for l=1:model_num
    inlier(:,((l-1)*pts_per_model+1):((l-1)*pts_per_model+pts_per_model)) = ...
        generateLinePts(gnd(:,l),pts_per_model,isig);
end


% Add gross noise.
X = rand(1,out_num);
Y = rand(1,out_num);

outlier = [ X ; Y ];

data = [inlier outlier];

end

% ------------------------------------------------
% generate parameters of a line a x + b y + c = 0.
% ------------------------------------------------
function [ par ] = generateLineParam

ang = rand*(pi/3-pi/6) + pi/6;
rad = rand*(1.0-0.2) + 0.2;

m = -tan(pi/2-ang);
x = rad*cos(ang);
y = rad*sin(ang);
c = y - m*x;

if (rand>0.5)
    x = -c/m;
    c = 1-x;
    m = -1/m;
end

par = [ m ; -1 ; c ];
par = par./norm(par);

end

% -------------------------------------------------------
% generate data points on a given line a x + b y + c = 0.
% -------------------------------------------------------
function [ pts par ] = generateLinePts(par,inum,isig)

m = -par(1)/par(2);
c = -par(3)/par(2);

if m>0    
    minX = max(-c/m,0);
    maxX = min((1-c)/m,1);
else    
    minX = max(0,(1-c)/m);
    maxX = min(1,-c/m);
end

X = rand(1,inum)*(maxX-minX)+minX;
Y = m*X + c*ones(1,length(X))+isig*randn(1,length(X));

pts = [ X; Y ];

end



