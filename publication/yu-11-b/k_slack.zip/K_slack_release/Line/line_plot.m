%----------------
% Plot a 2D line.
%----------------
function h = line_plot(hyp)

    x = -0.1+1.1*rand(1,50);
    y = hyp(1)*x+hyp(2);
    h = plot(x,y,'b-','LineWidth',1);
    
end