%-------------------------------------------------------------------
% Solve the LP reformulation of the minmax problem for line fitting.
%-------------------------------------------------------------------

function [ w alpha beta obj s] = minmax_line(X,y,K,eps)

[ n, d ] = size(X);
I = sparse(1:n,1:n,1);

% A and b as in Ax<=b+s in the primal
A1 = X;
b1 = y+eps;

A2 = -X;
b2 = -y+eps;

f = [ K; ones(n,1); sparse(n+d,1) ];

A = [ -ones(n,1) -I I sparse(n,d) ];
b = sparse(n,1);

A = [ A; sparse(n,n+1) -I A1 ];
b = [ b; b1 ];

A = [ A; sparse(n,n+1) -I A2 ];
b = [ b; b2 ];

dim = length(f);

lb = -inf*ones(dim,1);
lb(1+(1:2*n)) = 0;
ub = inf*ones(dim,1);

try
    % Set mosek optimization options.
    clear prob clear param
    [r,res]	= mosekopt('symbcon');
    sc	= res.symbcon;
    param = [];
    param.MSK_IPAR_INTPNT_BASIS	= sc.MSK_OFF;
    param.MSK_IPAR_INTPNT_MAX_ITERATIONS = 1000;
    param.MSK_DPAR_INTPNT_CO_TOL_PFEAS = 1.0e-8;
    param.MSK_DPAR_INTPNT_CO_TOL_DFEAS = 1.0e-8;
    param.MSK_DPAR_INTPNT_CO_TOL_REL_GAP = 1.0e-8;
    prob.c = f;
    prob.a = A;
    prob.blc = -inf*ones(length(b),1);
    prob.buc = b;
    prob.blx = lb;
    prob.bux = ub;
    
    % Invoke mosek solver.
    [r,res]=mosekopt('minimize',prob,param);
    
    % Read off the solution.
    sol = res.sol.itr.xx;
    obj = res.sol.itr.pobjval;
    alpha = sol(1);
    beta = sol(1+(1:n));
    s = sol(1+n+(1:n));
    w = sol(1+2*n+(1:d));
    
catch 
    
    error('Mosek fails during minmax optimization!');
    
end


end