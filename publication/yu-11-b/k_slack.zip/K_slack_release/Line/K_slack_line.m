%-----------------------------------
% K-slack approach for line fitting.
%-----------------------------------

function [ w, iter, removed ] = K_slack_line(X,y,xy,eps,K_ratio)
% input:
% X: (nxd) = n measurements of dimensionality d.
% y: (nx1) = n observed outputs.
% xy: (2xn) = x and y coordinates.
% eps: (1x1) = error tolerance.
% K_ratio: (1x1) = K value in ratio of n
%
% output:
% w: (2x1) = estimated line model.
% iter: (1x1) = number of iterations required.
% removed: (1x1) = number of removed data.

n = size(X,1);
iter = 0;

figure

while iter < 1 || K_ratio < 1
    K = max(1,ceil(K_ratio*length(y)));
    
    % Solve the minmax problem.     
    [ w alpha beta obj s ] = minmax_line(X,y,K,eps);
    iter = iter+1;
      
    if obj <= 1e-5
        fprintf('Obj: %.2e <= 1e-5\n',obj);
        break;
    end
    
    % Identify the top-k positive slacks
    [sorts sinx ] = sort(-s);
    topK = -sorts(1:K);
    topK = topK(topK > 1e-7);
    
    % Remaining data.
    int_inx = (s-topK(end))<-1e-6;
    
    % Plot the progress.
    clf
    plot(xy(1,:),xy(2,:),'b.','MarkerSize',16);
    hold on
    plot(xy(1,~int_inx),xy(2,~int_inx),'ro','MarkerSize',10);
    axis([-0.1 1 -0.1 1]);
    title(sprintf('K-slack approach (K = %d)',K),'FontSize',16);
    
    % Clean the data.
    X = X(int_inx,:);
    y = y(int_inx);
    xy = xy(:,int_inx);
    
    fprintf('----------------------------------------------------------------\n');
    fprintf('Iter: %d, obj: %.2e, remove %d outliers (K=%d)\n',iter,obj,sum(~int_inx),K);
end

% Number of removed data.
removed = n-size(X,1);

end


