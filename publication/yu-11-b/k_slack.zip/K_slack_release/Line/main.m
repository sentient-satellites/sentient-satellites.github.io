% ----------------------------------------------------------------- 
% An Adversarial Optimization Approach to Efficient Outlier Removal
% -----------------------------------------------------------------
% 
% The demo code in this package implements the outlier removal method
% proposed in: 
% 
% J. Yu, A. Eriksson, T.-J. Chin and D. Suter
% An Adversarial Optimization Approach to Efficient Outlier Removal 
% In Proc. International Conference on Computer Vision (ICCV), Barcelona,
% Spain, 2011.
% 
% Copyright (c) 2011 Jin Yu 
% School of Computer Science, The University of Adelaide, South Australia 
% http://www.cs.adelaide.edu.au/~jinyu
% 
% The program is free for non-commercial academic use. Any commercial use
% is strictly prohibited without the author's consent. Please acknowledge
% the author by citing the above paper in any academic publications that
% have made use of this package or part of it.
%
% This program makes use of the Mosek LP sover (http://mosek.com).
% 
% If you encounter any problems or questions please email to 
% jin.yu@adelaide.edu.au.
 

close all;
clear all;

%-----------------------
% Set up the experiment.
%-----------------------

% Number of inliers.
inl_num = 50;

% Outlier ratio.
out_ratio = 0.25;

% Inlier noise.
isig = 0.02;

% K value in ratio of the overall number of data.
K_ratio = 0.05; % to run the 1-slack method, set K_ratio = 0.

% Error tolerance.
eps = 0.04;


%---------------
% Generate data.
%---------------

out_num = round(out_ratio*inl_num/(1-out_ratio));
[ xy, gnd ] = genLines(1,inl_num,isig,out_num);


% Set up the data matrix for regression.
n = size(xy,2);
X = [ xy(1,:)', ones(n,1) ];
y = xy(2,:)';


%----------------------
% Run K-slack approach.
%----------------------

[ w, iter, removed ] = K_slack_line(X,y,xy,eps,K_ratio);

fprintf('----------------------------------------------------------------\n');
fprintf('K-slack (K=%.2fxN) done in %d iterations, removed %d points. \n',K_ratio,iter,removed);
fprintf('----------------------------------------------------------------\n');


%-------------------------------
% Plot the final fitting result.
%-------------------------------

figure
hold on
plot(xy(1,:),xy(2,:),'.');
line_plot(w);
title(sprintf('K-slack (K = %.2fxN)',K_ratio),'FontSize',16);




