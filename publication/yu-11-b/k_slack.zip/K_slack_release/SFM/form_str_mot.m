% Assemble the solution for SfM. The code is downloaded from:
% http://www.maths.lth.se/matematiklth/personal/calle/Outl_dual/Outl_dual.html. 

function [U,P] = form_str_mot(u,A,sol)
numpts = size(u{1},2);

U = reshape(sol(1:(3*numpts)),[3 numpts]);

tpart = [0;0;0;sol(3*numpts+1:end)];
P = cell(size(A));
for i=1:length(A)
    P{i} = [A{i} tpart((i-1)*3+1:i*3)];
end
end