%----------------------------------------------
% Compute the RMS and maximum residual for SfM.
%----------------------------------------------

function [res, maxerr] = compute_res_sfm(P,U,u)

if size(U,1)==3
    U = [U; ones(1,size(U,2))];
end

res = 0;
npts = 0;
maxerr = -inf;

for i = 1:length(P);
    vis = isfinite(u{i}(1,:));
    xerr = ((P{i}(1,:)*U(:,vis))./(P{i}(3,:)*U(:,vis)) - u{i}(1,vis)).^2;
    yerr = ((P{i}(2,:)*U(:,vis))./(P{i}(3,:)*U(:,vis)) - u{i}(2,vis)).^2;
    tmp = sum([xerr; yerr]);
    maxerr = max([maxerr tmp]);
    res = res + sum(tmp);
    npts = npts+sum(vis);
end

% Root mean square residual.
res = sqrt(res/(2*npts));

% Maximum residual.
maxerr = sqrt(maxerr);

end