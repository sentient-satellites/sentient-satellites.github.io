% A slightly modified version of Carl Olsson's implementation of the dual
% one-slack method for SfM; please see
% http://www.maths.lth.se/matematiklth/personal/calle/Outl_dual/Outl_dual.h
% tml. 



function [U,P,dual,s] = krot_feas(u,A,tol,min_depth,max_depth)
% Solves the known rotation feasibility problem
% Olsson, Eriksson, Hartley, Outlier Removal using Duality, CVPR2010
%
% inputs -  u: 1xD cell with image data.
%           u{i} is of size 3xN, where N is the number of observed points.
%           If point j is not observed in image then u{i}(:,j) = NaN.
%
%        -  A: 1xD cell with estimated orientation matrices.
%
%        -  tol: maximal inlier tolerance.
%
%        -  min_depth: minimal allowed depth.
%
%        -  max_depth: maximal allowed depth.
%
% outputs - U: 3xD cell with 3D points
%
%         - P: 1xD cell with camera matrices
%
%         - dual: solution to the dual variables. dual(i) > 0 indicates that U(:,i) might
%           be an outlier if s > 0
%

[a,a0,b,b0,c,c0,Aeq,Beq] = gen_krot(u,A);
[Linfsol,dual,s] = LinfSolverfeas(a,a0,b,b0,c,c0,Aeq,Beq,tol,min_depth,max_depth);
[U,P] = form_str_mot(u,A,Linfsol);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Y,dual,s] = LinfSolverfeas(a,a0,b,b0,c,c0,Aeq,Beq,tol,min_depth,max_depth)

A1 = [-a-tol*c; a-tol*c; -b-tol*c; b-tol*c];
B1 = [a0+tol*c0; -a0+tol*c0; b0+tol*c0; -b0+tol*c0];

A2 = [-c; c];
B2 = [c0-min_depth; max_depth-c0];

A = [A1 -ones(size(A1,1),1);A2 zeros(size(A2,1),1)];
C = [B1;B2];
B = [sparse(size(A1,2),1); 1];

clear prob clear param 
[r,res]	= mosekopt('symbcon'); 
sc	= res.symbcon;
param = [];
param.MSK_IPAR_INTPNT_BASIS	=  sc.MSK_OFF;
param.MSK_IPAR_INTPNT_MAX_ITERATIONS = 1000;
param.MSK_DPAR_INTPNT_CO_TOL_PFEAS = 1.0e-8;
param.MSK_DPAR_INTPNT_CO_TOL_DFEAS = 1.0e-8;
param.MSK_DPAR_INTPNT_CO_TOL_REL_GAP = 1.0e-8;

prob.c = C;
prob.a = A';
prob.blc = -B;
prob.buc = -B;
prob.blx = sparse(length(C),1);
prob.bux = [];

% Use Mosek instead of SeDuMi (as used in Olsson's code) LP solver.
[r,res] = mosekopt('minimize',prob,param);


Y = res.sol.itr.y;
X = res.sol.itr.xx;

s = Y(end);
Y = Y(1:end-1);
res = size(a,1);
dual = X(1:res)+X(res+1:2*res)+X(2*res+1:3*res)+X(3*res+1:4*res)+X(4*res+1:5*res)+X(5*res+1:end);


end