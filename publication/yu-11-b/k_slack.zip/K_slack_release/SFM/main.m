% ----------------------------------------------------------------- 
% An Adversarial Optimization Approach to Efficient Outlier Removal
% -----------------------------------------------------------------
% 
% The demo code in this package implements the outlier removal method
% proposed in: 
% 
% J. Yu, A. Eriksson, T.-J. Chin and D. Suter
% An Adversarial Optimization Approach to Efficient Outlier Removal 
% In Proc. International Conference on Computer Vision (ICCV), Barcelona,
% Spain, 2011.
% 
% Copyright (c) 2011 Jin Yu 
% School of Computer Science, The University of Adelaide, South Australia 
% http://www.cs.adelaide.edu.au/~jinyu
% 
% The program is free for non-commercial academic use. Any commercial use
% is strictly prohibited without the author's consent. Please acknowledge
% the author by citing the above paper in any academic publications that
% have made use of this package or part of it.
% 
% This program is based on Carl Olsson's implementation of the 1-slack
% method for Structure from Motion problems, please see 
% http://www.maths.lth.se/matematiklth/personal/calle/Outl_dual/Outl_dual.html. 
% 
% It also makes use of the Mosek LP sover (http://mosek.com).
%
% If you encounter any problems or questions please email to 
% jin.yu@adelaide.edu.au.


close all;
clear all;

%-----------
% Load data.
%-----------
dir = './data/';
datasets = {'dino_15out','uwo','house','cathedral','cathedral_15out'};

data = datasets{1};
load([dir data '_rotations.mat']);
load([dir data '_calib.mat'], 'KK');

% Remove points that are visible in less than two cameras.
vis = zeros(1,size(u{1},2));
for i=1:length(u)
    vis = vis + isfinite(u{i}(1,:));
end
init_obs = sum(vis.*(vis>1));

vis = vis >= 2;
for i = 1:length(u)
    u{i} = u{i}(1:2,vis);
end

fprintf('Dataset: %s loaded: %d cameras, %d points, %d observations.\n',data,length(u),size(u{1},2), init_obs); 


%-----------------------
% Set up the experiment.
%-----------------------

% K value in ratio of the overall number of the 2D observations. 
K_ratio = 0.1; % to run the 1-slack method, set K_ratio = 0.

% Error tolerance in pixel.
eps = 2/KK(1,1); % 2 pixels

% Depth range.
max_depth = 1e2;
min_depth = 1e-1;


%----------------------
% Run K-slack approach.
%----------------------

if K_ratio > 0
    % Run K-slack approach
    [P, U, u, iter, removed_obs, removed_pts ] = K_slack_sfm(u,A,K_ratio,eps,min_depth,max_depth);
    
else
    % Use Carl Olsson's implementation of the 1-slack method. It does not
    % require sorting slack variables, hence faster.
    [P, U, u, iter, removed_obs, removed_pts ] = one_slack_sfm(u,A,eps,min_depth,max_depth);
end


% Computer reprojection error.
[rms,maxerr] = compute_res_sfm(P,U,u);
rms = rms*KK(1,1); %rms in pixels.


fprintf('-------------------------------------------------------------------------------------------------\n');
fprintf('K-slack (K=%.2fxN) done in %d iterations, removed %d observations (%d 3D points), RMS = %.2f.\n',K_ratio,iter,removed_obs,removed_pts,rms);
fprintf('-------------------------------------------------------------------------------------------------\n');


%--------------------
% Plot the structure.
%--------------------
plot3(U(1,:),U(2,:),U(3,:),'.','MarkerSize',2);
title(sprintf('K-slack (K = %.2fxN)',K_ratio),'FontSize',16);
axis equal;


