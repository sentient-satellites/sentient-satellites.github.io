%--------------------------
% K-slack approach for SfM.
%--------------------------

function [ P, U, u, iter, removed_obs, removed_pts ] = K_slack_sfm(u,A,K_ratio,eps,min_depth,max_depth)
% input:
% u: (1xC) = cell with image data of C cameras, u{j} is a 3xn matrix
% containing observed points. If point i is not observed in image j,
% u{j}(:,i) = NaN.
% A: (1xC) = cell with estimated camera rotation matrices.
% K_ratio (1x1) = K value in ratio of observations.
% eps: (1x1) = error tolerance.
% min_depth: (1x1) = minimum structure depth.
% max_depth: (1x1) = maximum structure depth.
%
% output:
% P: (1xC) = cell containing estimated camera matrices.
% U: (3xC) = cell containing estimated 3D points.
% u: (1XC) = cell containing the remaining observations.
% iter: (1x1) = number of iterations required.
% removed_obs: (1x1) = number of removed observations.
% removed_pts: (1x1) = number of removed 3D points.


iter = 0;
removed_obs = 0;
removed_pts = 0;
U = [];
P = [];

while iter < 1 || K_ratio < 1 % if K_ratio = 1, then only one run of K-slack is needed.

    [ U, P, alpha, beta, obj, s, K ] = minmax_sfm(u,A,eps,min_depth,max_depth,K_ratio);
    iter = iter+1;
      
    if obj <= 1e-5
        break;
    end
    
    [sorts sinx ] = sort(-s);
    topK = -sorts(1:K);
    topK = topK(topK > 1e-7);
    if isempty(topK)
        break;
    end
    out_inx = (s-topK(end))>-1e-7;
    
    % Remove outliers.
    removed_obs_cur = 0;
    for i = 1:length(u);
        vis = find(isfinite(u{i}(1,:)));
        res = length(vis);
        u{i}(:,vis(out_inx(1:res))) = NaN;
        removed_obs_cur = removed_obs_cur+sum(out_inx(1:res));
        out_inx = out_inx((res+1):end);
    end
    removed_obs = removed_obs+removed_obs_cur;

    % Remove points that are visible in less than 2 views.
    removed_pts_cur = size(u{1},2);

    vis = zeros(1,size(u{1},2));
    for i=1:length(u)
        vis = vis + isfinite(u{i}(1,:));
    end
    vis = vis >= 2;
    for i = 1:length(u)
        u{i} = u{i}(:,vis);
    end
    U = U(:,vis);
    
    removed_pts_cur = removed_pts_cur-size(u{1},2);
    removed_pts = removed_pts+removed_pts_cur;

    % Report progress.
    fprintf('----------------------------------------------------------------------------------\n');
    fprintf('Iter: %d, obj: %.2e, remove %d observations (%d 3D points), K=%d\n', iter,obj,removed_obs_cur,removed_pts_cur,K);
end


