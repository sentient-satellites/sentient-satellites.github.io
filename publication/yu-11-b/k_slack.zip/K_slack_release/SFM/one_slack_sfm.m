% A slightly modified version of Carl Olsson's implementation of one-slack
% method for SfM; please see
% http://www.maths.lth.se/matematiklth/personal/calle/Outl_dual/Outl_dual.h
% tml. 

function [ P, U, u, iter, removed_obs, removed_pts ] = one_slack_sfm(u,A,eps,min_depth,max_depth)
% input:
% u: (1xC) = cell with image data of C cameras, u{j} is a 3xn matrix
% containing observed points. If point i is not observed in image j,
% u{j}(:,i) = NaN.
% A: (1xC) = cell with estimated camera rotation matrices.
% K_ratio (1x1) = K value in ratio of observations.
% eps: (1x1) = error tolerance.
% min_depth: (1x1) = minimum structure depth.
% max_depth: (1x1) = maximum structure depth.
%
% output:
% P: (1xC) = cell containing estimated camera matrices.
% U: (3xC) = cell containing estimated 3D points.
% u: (1XC) = cell containing the remaining data.
% iter: (1x1) = number of iterations required.
% removed_obs: (1x1) = number of removed observations.
% removed_pts: (1x1) = number of removed 3D points.

iter = 1;
removed_obs = 0;
removed_pts = 0;

[U,P,dual,s] = krot_feas(u,A,eps,min_depth,max_depth);

while s > 0 %Chack if there are outliers
    
    %Remove outliers
    removed_obs_cur = 0;
    Uold = U;
    Pold = P;
    for i = 1:length(u);
        vis = find(isfinite(u{i}(1,:)));
        res = length(vis);
        u{i}(:,vis(dual(1:res) > 1e-7)) = NaN;
        removed_obs_cur = removed_obs_cur+sum(dual(1:res) > 1e-7);
        dual = dual(res+1:end);
    end
    removed_obs = removed_obs+removed_obs_cur;
    
    %Remove points that are visible in less than 2 views
    removed_pts_cur = size(u{1},2);
    
    vis = zeros(1,size(u{1},2));
    for i=1:length(u)
        vis = vis + isfinite(u{i}(1,:));
    end
    vis = vis >= 2;
    for i = 1:length(u)
        u{i} = u{i}(:,vis);
    end
    removed_pts_cur = removed_pts_cur-size(u{1},2);
    removed_pts = removed_pts+removed_pts_cur;
    
    %Solve the feasibility problem again
    [U,P,dual,s] = krot_feas(u,A,eps,min_depth,max_depth);
    
    % Report progress
    fprintf('----------------------------------------------------------------------\n');
    fprintf('Iter: %d, obj: %.2e, remove %d observations (%d 3D points), K=%d\n', iter,s,removed_obs_cur,removed_pts_cur,1);
    
    iter = iter+1;
    
    
end

P = Pold;
U = Uold(:,vis);

end