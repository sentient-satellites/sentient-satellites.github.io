 ----------------------------------------------------------------- 
 An Adversarial Optimization Approach to Efficient Outlier Removal
 -----------------------------------------------------------------
 
 The demo code in this package implements the outlier removal method
 proposed in: 
 
 J. Yu, A. Eriksson, T.-J. Chin and D. Suter
 An Adversarial Optimization Approach to Efficient Outlier Removal 
 In Proc. International Conference on Computer Vision (ICCV), Barcelona,
 Spain, 2011.
 
 Copyright (c) 2011 Jin Yu 
 School of Computer Science, The University of Adelaide, South Australia 
 http://www.cs.adelaide.edu.au/~jinyu
 
 The program is free for non-commercial academic use. Any commercial use
 is strictly prohibited without the author's consent. Please acknowledge
 the author by citing the above paper in any academic publications that
 have made use of this package or part of it.
 
 This program makes use of Carl Olsson's implementation of the 1-slack
 method for Structure from Motion problems, please see 
 http://www.maths.lth.se/matematiklth/personal/calle/Outl_dual/Outl_dual.html. 
 
 The Mosek LP sover used in this program can be downloaded for free for
 academic use from http://mosek.com.

 If you encounter any problems or questions please email to 
 jin.yu@adelaide.edu.au.


------------
Instructions
------------
1. Install Mosek.
2. Uncompress the package.
3. Go to one of the three directories: "Line', "Hom", and "SFM" 
   for 2D line fitting, homography estimation, and Structure from Motion, 
   respectively. Sample data for homography estimation and Structure 
   from Motion are given in the "data" subdirectory.
4. Run the file 'main.m'. 

