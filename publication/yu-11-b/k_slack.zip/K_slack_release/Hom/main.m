% ----------------------------------------------------------------- 
% An Adversarial Optimization Approach to Efficient Outlier Removal
% -----------------------------------------------------------------
% 
% The demo code in this package implements the outlier removal method
% proposed in: 
% 
% J. Yu, A. Eriksson, T.-J. Chin and D. Suter
% An Adversarial Optimization Approach to Efficient Outlier Removal 
% In Proc. International Conference on Computer Vision (ICCV), Barcelona,
% Spain, 2011.
% 
% Copyright (c) 2011 Jin Yu 
% School of Computer Science, The University of Adelaide, South Australia 
% http://www.cs.adelaide.edu.au/~jinyu
% 
% The program is free for non-commercial academic use. Any commercial use
% is strictly prohibited without the author's consent. Please acknowledge
% the author by citing the above paper in any academic publications that
% have made use of this package or part of it.
%
% This program makes use of the Mosek LP sover (http://mosek.com).
%
% If you encounter any problems or questions please email to 
% jin.yu@adelaide.edu.au.


clear all;
close all;

%----------------------------
% Load image correspondences.
%----------------------------

data = 'graf'; %'keble'
matches = load(sprintf('data/%s-match.mat',data));
fprintf('Dataset: %s loaded with %d matches\n',data,size(matches.X1,2));


%-----------------------
% Set up the experiment.
%-----------------------

% K value in ratio of the overall number of the matches. 
K_ratio = 0.15; % to run the 1-slack method, set K_ratio = 0.

% Error tolerance (in pixels)
eps = 2;

% Depth range.
max_depth= 1e3;
min_depth = 1e-3;


%----------------------
% Run K-slack approach.
%----------------------

[ H, X, iter, removed ] = K_slack_hom(matches,K_ratio,eps,min_depth,max_depth);


% Compute reprojection error.
[ rms, max_error ] = compute_res_hom(H,X);


fprintf('-------------------------------------------------------------------------\n');
fprintf('K-slack (K=%.2fxN) done in %d iterations, removed %d matches, RMS = %.2f.\n',K_ratio,iter,removed,rms);
fprintf('-------------------------------------------------------------------------\n');
