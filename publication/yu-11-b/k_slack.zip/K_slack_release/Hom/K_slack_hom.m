%--------------------------------------------
% K-slack approach for homography estimation.
%--------------------------------------------

function [ H, X, iter, removed ] = K_slack_hom(matches,K_ratio,eps,min_depth,max_depth)
% input:
% matches: (1x1) = structure containing images and keypoint matches.
% K_ratio: (1x1) = K value in ratio of n.
% eps: (1x1) = error tolerance.
%
% output:
% H: (3x3) = estimated homography matrix.
% X: (6xN) = remaining matches.
% iter: (1x1) = number of iterations required.
% removed: (1x1) = number of removed data.

% Keypoint matches.
X = [ matches.X1; matches.X2 ];

n = size(X,2);
iter = 0;

figure

while iter < 1 || K_ratio < 1 % if K_ratio = 1, then only one run of K-slack is needed.
    
    [ h alpha beta obj s K]  = minmax_hom(X,eps,min_depth,max_depth,K_ratio);
    iter = iter+1;
    
    if obj <= 1e-5
        fprintf('Obj: %.2e <= 1e-5\n',obj);
        break;
    end
    
    [sorts sinx ] = sort(-s);
    topK = -sorts(1:K);
    
    topK = topK(topK > 1e-7);
    int_inx = (s-topK(end))<-1e-6;
    
    % Remove outliers.
    X = X(:,int_inx);
    
    % Plot the remaining matches.
    clf;
    plot_match(matches,X);
    
    % Report progress.
    fprintf('----------------------------------------------------------------\n');
    fprintf('Iter: %d, obj: %.2e, remove %d outliers (K=%d)\n',iter,obj,sum(~int_inx),K);
    
end

% Number of removed data.
removed = n-size(X,2);


% Assemble the output.
h = [h; 1]';
H = [h(1:3);h(4:6);h(7:9)];


end


