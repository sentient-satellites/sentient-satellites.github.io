%-----------------------
% Plot keypoint matches.
%-----------------------
function plot_match(a,X)

im1 = a.im1;
im2 = a.im2;

dh1 = max(size(im2,1)-size(im1,1),0);
dh2 = max(size(im1,1)-size(im2,1),0);


subplot(2,1,1)
imagesc([padarray(im1,dh1,'post') padarray(im2,dh2,'post')]);
o = size(im1,2);
line([a.X1(1,:);a.X2(1,:)+o], [a.X1(2,:);a.X2(2,:)]);
axis image off;


subplot(2,1,2)
imagesc([padarray(im1,dh1,'post') padarray(im2,dh2,'post')]);
o = size(im1,2);
line([X(1,:);X(4,:)+o], [X(2,:);X(5,:)]);

axis image off;
drawnow;


end