
%---------------------------------------------------------------------
% Solve the LP reformulation of the minmax problem for homography est.
%---------------------------------------------------------------------
function [ w alpha beta obj s K ] = minmax_hom(X,tol,min_depth,max_depth,K_ratio)

% Set up the LP
a = [];
a0 = [];
b = [];
b0 = [];
c = [];
c0 = [];

v = X(1:2,:);
u = X(4:5,:);


for i = 1:size(X,2)
    a = [a; [v(:,i)' 1]  sparse(1,3) -u(1,i)*v(1,i) -u(1,i)*v(2,i)];
    a0 = [a0; -u(1,i)];
    
    b = [b; sparse(1,3) [v(:,i)' 1] -u(2,i)*v(1,i) -u(2,i)*v(2,i)];
    b0 = [b0; -u(2,i)];
    
    c = [c; sparse(1,6) v(1:2,i)'];
    c0 = [c0; 1];
end

A1 = [-a-tol*c; a-tol*c; -b-tol*c; b-tol*c];
B1 = [a0+tol*c0; -a0+tol*c0; b0+tol*c0; -b0+tol*c0];

A2 = [-c; c];
B2 = [c0-min_depth; max_depth-c0];

n = size(a,1);
d = size(A1,2);
I = sparse(1:n,1:n,1);

K = max(1,ceil(K_ratio*n));

f = [ K; ones(n,1); sparse(n+d,1) ];

A = [ -ones(n,1) -I I sparse(n,d) ];
b = sparse(n,1);

A = [ A; sparse(4*n,n+1) repmat(-I,4,1) A1 ];
b = [ b; B1 ];

A = [ A; sparse(2*n,n+1) repmat(-I,2,1) A2 ];
b = [ b; B2 ];

dim = length(f);
lb = -inf*ones(dim,1);
lb(1+(1:2*n)) = 0;
ub = inf*ones(dim,1);

try
    % Set mosek optimization options.
    clear prob clear param
    [r,res]	= mosekopt('symbcon');
    sc	= res.symbcon;
    param = [];
    param.MSK_IPAR_INTPNT_BASIS	=  sc.MSK_OFF;
    param.MSK_IPAR_INTPNT_MAX_ITERATIONS = 1000;
    param.MSK_DPAR_INTPNT_TOL_PFEAS = 1.0e-8;
    param.MSK_DPAR_INTPNT_TOL_DFEAS = 1.0e-8;
    param.MSK_DPAR_INTPNT_TOL_REL_GAP = 1.0e-8;
    prob.c = f;
    prob.a = A;
    prob.blc = -inf*ones(length(b),1);
    prob.buc = b;
    prob.blx = lb;
    prob.bux = ub;
    
    % Invoke mosek solver.    
    [r,res]=mosekopt('minimize',prob,param);
    
    % Read off the solution.
    sol = res.sol.itr.xx;
    obj = res.sol.itr.pobjval;
    alpha = sol(1);
    beta = sol(1+(1:n));
    s = sol(1+n+(1:n));
    w = sol(1+2*n+(1:d));
    
catch
    error('Mosek fails during minmax optimization!');
end


end

