%---------------------------------------------------------
% Compute the RMS and maximum residual for homography est.
%---------------------------------------------------------
function [rms, maxerr] = compute_res_hom(H,X)

X1 = X(1:3,:);
X2 = X(4:6,:);

X2_ = H*X1 ;
dx = X2_(1,:)./X2_(3,:) - X2(1,:)./X2(3,:) ;
dy = X2_(2,:)./X2_(3,:) - X2(2,:)./X2(3,:) ;

% Root mean square residual
res = dx.*dx + dy.*dy;
rms = sqrt(sum(res)/(2*size(X,2)));

% Maximum residual.
maxerr = sqrt(max(res));

end