%% 'smoothSinglepath.m' calculates the original camera motion chain and optimizes the path C with
%   single path optimization method.
% by William Liu

%% Calculate the original camera motion chain
C = zeros(9,fnum);
for t = 1:fnum
    if t == 1
        C(:,1) = reshape(eye(3),9,1);
    else
        Ci = reshape(C(:,t-1),3,3);
        Ci = Ci * Hs{t-1};
        Ci = Ci/Ci(3,3);
        C(:,t) = reshape(Ci,9,1);
    end
end
save(fullfile(dataDir,'C_sp.mat'),'C');

%% Then optimize the path C
T = 30000; % iteration number
lambda = 5; % empirically
width = 30; % neiborhood width is 60, 30 frames on both sides

% Optimize C to get P
Ppre = C;   % initialize P with C
P = C;
% termination threshold
threshold = 1e-3;

for i = 1:T
    % Optimize frame by frame
    for t = 2:fnum
        % choose neighborhood for current frame
        leftInd = max(1,t-width);
        rightInd = min(fnum,t+width);
        omega = [leftInd:t-1,t+1:rightInd];
        wtr = zeros(1,fnum);
        % estimate the adaptive weight
        for r = omega
            wtr(r) = exp(-abs(r-t)^2./10^2);
        end
        wtr = wtr / sum(wtr(omega));
        wtrsum = sum(wtr(omega));
        gamma = 1 + 2*lambda*wtrsum;
        % update camera motion
        Pr = repmat(wtr(omega),9,1).*P(:,omega);
        Pt = (C(:,t) + 2*lambda*sum(Pr,2))/gamma;
        if isnan(Pt)
            break;
        end
        P(:,t) = Pt;
    end
    % if P converges to Pcur
    fprintf('%d-th iteration: norm(P) = %0.5f\t %0.5f\n',i,norm(P),norm(Ppre));
    if abs(norm(P) - norm(Ppre)) < threshold
        break;
    else
        % update Ppre with P and continue
        Ppre = P;
    end
end
save(fullfile(dataDir,'P_sp.mat'),'P');
fprintf('Took %d iterations to reach convergence!\n',i);
