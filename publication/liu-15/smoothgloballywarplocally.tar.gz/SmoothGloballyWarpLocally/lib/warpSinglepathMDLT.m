%% 'warpSinglepathMDLT.m' Warps output frames using MDLT
% by William Liu

%%
close all;

%% Directory setup
mkdir warp_sp_mdlt  % Single path + Homography field warping
warpDir = 'warp_sp_mdlt';

% read in image dir
inputs_dir = fullfile(dataDir,'png');
inputs = dir(fullfile(inputs_dir,'*.png'));

fnum = length(inputs);

% load in feature points
load(fullfile(dataDir,'fpts'));
fptsUpdated = zeros(size(fpts));
% load in the original camera path
load(fullfile(dataDir,'C_sp'));
% load in the desired path
load(fullfile(dataDir,'P_sp'));

%% Parameter setup
thr = 0.01;
sigma = 8;
gamma = 0.05;   % gamma for first stage
reso = 20;

% get frame size
img = imread(fullfile(inputs_dir,inputs(1).name));
img = imresize(img,1);
[height, width, ~] = size(img);

%% Use current frame homography from MDLT to warp
for t = 1:fnum
  fprintf('Warping %d/%d-th frame....\n',t,fnum); tic;
  if t == 1 % if it's about the first frame, then just copy
    warpedimg = img;
    fp = fpts(2*t-1:2*t,:);
  else % load the previous img, imgr
    img2 = imread(fullfile(inputs_dir,inputs(t).name)); % current frame
    p1 = fpts(2*(t-1)-1:2*(t-1),:);
    p2 = fpts(2*t-1:2*t,:);
    % remove zeros
    fs = [p1;p2];
    [~,iy] = find(fs == 0);
    fs(:,iy) = [];
    
    % outlier removal
    p1 = fs(1:2,:);
    p2 = fs(3:4,:);
    pts1 = makehomogeneous(p1);
    pts2 = makehomogeneous(p2);
    % outlier removal
    [~,inliers] = ransacfithomography(pts1,pts2,thr);
    pts1 = pts1(:,inliers);
    pts2 = pts2(:,inliers);
    
    % normalize feature points
    [pts1n, T1] = normalise2dpts(pts1);
    [pts2n, T2] = normalise2dpts(pts2);
    [h,A] = homography2d([pts1;pts2]);
    fprintf('[Done]: Outlier [%0.2fs]    ',toc);
    
    %% Desired camera path from previous frame to current frame
    Pt = reshape(P(:,t),3,3);
    Ctm1 = reshape(C(:,t-1),3,3);
    Ct = reshape(C(:,t),3,3);
    Bt = Ct\Pt;
    
    %% Moving DLT (projective).
    % Generating mesh for MDLT.
    [X, Y] = meshgrid(linspace(1, width, reso), linspace(1, height, reso));
    xstep = (X(1,2) - X(1,1))/2;
    ystep = (Y(2,1) - Y(1,1))/2;
    % Mesh's vertices coordinates.
    Mvts = [X(:) Y(:)];
    % Obtain Gaussian kernel
    D = pdist2(Mvts, makeinhomogeneous(pts1)');
    
    % Capping/offsetting kernel
    GaussK = exp(-D ./ sigma^2);
    GaussK = max(gamma, GaussK);
    % Normalize kernel and compute Weights
    W = GaussK ./ repmat(sum(GaussK, 2), 1, size(pts1,2));
    
    % Perform Moving DLT
    H = zeros(size(Mvts, 1), 9);
    for i = 1:size(Mvts, 1)
      % Get Weights (w*) focused in current cell
      w = W(i, :);
      w = [w;w]; w = w(:);
      w = repmat(w,1,9);
      % Multiply the weights by the A matrix from global Homography
      wA = w.*A;
      
      % Solve for B (extract nullspace)
      [~, ~, v] = svd(wA, 0);
      h = v(:, 9); % h contains the Homography for current cell
      h = reshape(h, 3, 3)';
      % De-condition
      h = T2 \ h * T1;
      h = Pt\(Ctm1*h);
      H(i, :) = h(:);
    end
    
    for d = 1:9
      H(:,d) = H(:,d)./H(:,9);
    end
    fprintf('Hs-est [%0.2fs]    ',toc);
    
    %% Warping
    warpIm = zeros(size(img2));
    fp = fpts(2*t-1:2*t,:);
    im = double(img2);
    
    for i = 1:size(Mvts,1)
      result = [];
      cellcenter = Mvts(i,:);% first cell center
      % boundary on source img
      xsmin = max(floor(cellcenter(1)-xstep),1);
      xsmax = min(ceil(cellcenter(1)+xstep),width);
      ysmin = max(floor(cellcenter(2)-ystep),1);
      ysmax = min(ceil(cellcenter(2)+ystep),height);
      
      in = inpolygon(fp(1,:),fp(2,:), ...
        [xsmin xsmax xsmax xsmin xsmin], ...
        [ysmin ysmin ysmax ysmax ysmin]);
      fpi = fp(:,in);
      hi = reshape(H(i,:),3,3);
      
      if ~isempty(fpi)
        fpi = hi \ makehomogeneous(fpi);
        fpi = makeinhomogeneous(fpi);
      end
      
      % pixels on source img
      [xSrc,ySrc] = meshgrid(xsmin:xsmax-1,ysmin:ysmax-1);
      pixelTar = hi*makehomogeneous([xSrc(:)';ySrc(:)']);
      pixelTar = makeinhomogeneous(pixelTar);
      patchSize = [ysmax-ysmin,xsmax-xsmin];
      xTar = reshape(pixelTar(1,:),patchSize);
      yTar = reshape(pixelTar(2,:),patchSize);
      
      result(:,:,1) = interp2(im(:,:,1),xTar,yTar,'cubic');
      result(:,:,2) = interp2(im(:,:,2),xTar,yTar,'cubic');
      result(:,:,3) = interp2(im(:,:,3),xTar,yTar,'cubic');
      
      warpIm(ysmin:ysmax-1,xsmin:xsmax-1,1) = result(:,:,1);
      warpIm(ysmin:ysmax-1,xsmin:xsmax-1,2) = result(:,:,2);
      warpIm(ysmin:ysmax-1,xsmin:xsmax-1,3) = result(:,:,3);
    end
    warpedimg = uint8(warpIm);
    fprintf('Warp [%0.2fs]    \n\n',toc);
  end
  
  targetDir = fullfile(warpDir,inputs(t).name);
  imwrite(warpedimg,targetDir);
end
