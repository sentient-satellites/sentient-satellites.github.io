%% 'warp2vid.m' Converts frames to video
%  video name is specified by 'prefixwarp'
% by William Liu

%%
function warp2vid(prefixwarp)
prefixori = 'data/png';

allimg = dir(fullfile(prefixori,'*.png'));
fnum = length(allimg);

vidName = sprintf([prefixwarp,'.avi']);
vidObj = VideoWriter(vidName);
vidObj.FrameRate = 20;
open(vidObj);

% outputVideo.
for i = 1:fnum
    fprintf('Writing in the %d/%d-th frame....\n',i,fnum);
    
    imgori = imread(fullfile(prefixori,allimg(i).name));
    imgwarp = imread(fullfile(prefixwarp,allimg(i).name));
    
    [h, w, ~] = size(imgori);
    gap = zeros(h,5,3);
    gap(:,:,2) = 255;
 
    img = [imgori uint8(gap) imgwarp];
    img = insertText(img, [250,h-100], 'Original', 'FontSize', 36, 'BoxColor', 'yellow', 'BoxOpacity', 0.7);
    img = insertText(img, [w+250,h-100], 'Stabilized', 'FontSize', 36, 'BoxColor', 'yellow', 'BoxOpacity', 0.7);

    writeVideo(vidObj,img);
end
close(vidObj);
