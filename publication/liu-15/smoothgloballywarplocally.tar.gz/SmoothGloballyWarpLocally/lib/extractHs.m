%% 'extractHs.m' calculates inter-frame homographies.
% by William Liu

%%
function extractHs(dataDir)

fprintf('Calculating inter-frame homography!\n');

% load in feature points and all original images
fpts = load(fullfile(dataDir,'fpts')); fpts = fpts.fpts;
imgdir = fullfile(dataDir,'png');
allimg = dir(fullfile(imgdir,'*.png'));
fnum = length(allimg);

Hs = cell(1,fnum-1);

for i = 1:fnum-1
    fprintf('Processing the %d/%d -th frame ... \n', i, fnum);
    p1 = fpts(2*i-1:2*i,:);
    p2 = fpts(2*(i+1)-1:2*(i+1),:);
    
    % remove zeros
    fs = [p1;p2];
    [~,iy] = find(fs == 0);
    fs(:,iy) = [];
    p1 = fs(1:2,:);
    p2 = fs(3:4,:);
    
    % estimate homography from image 1 -> image 2, st. p2 = H * p1.
    [H12,~] = ransacfithomography(p1,p2,0.01);
    % save the homography
    Hs{i} = H12;
end
save(fullfile(dataDir,'Hs.mat'),'Hs');
end
