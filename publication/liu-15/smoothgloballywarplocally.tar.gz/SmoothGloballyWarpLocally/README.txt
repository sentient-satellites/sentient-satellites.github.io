Smooth Globally Warp Locally: Video Stabilization using Homography Fields 

The MATLAB demo code in this package implements (only) the video stabilization method proposed in:

"Smooth Globally Warp Locally: Video Stabilization using Homography Fields", 
William X. Liu, Tat-Jun Chin.
In International Conference on Digital Image Computing: Techniques and Applications (DICTA),
Adelaide, 2015

For using this demo, please first convert input video '1.mp4' to frames by using the following commands in terminal:

	cd SmoothGloballyWarpLocally
	mkdir data/png
	ffmpeg -i 1.mp4 -r 30 data/png/frame%03d.png

Then run the "main.m" file in MATLAB, which produces a video result:
	warp_sp_mdlt.avi: stabilized with single path optimization and warped using homography fields.


In this package, all codes are implemented using Matlab, while some codes are obtained from toolbox 'MATLAB and Octave functions for Computer Vision and Image Processing' by Peter Kovesi, which can be downloaded from www.peterkovesi.com
.
For the included video '1.mp4', optic flow based features have been extracted 'data/fpts.mat' by using 'Dense point trajectories by GPU-accelerated large displacement optical flow' by Narayanan Sundaram, Thomas Brox and Kurt Keutzer. The implementation can be downloaded from http://lmb.informatik.uni-freiburg.de/resources/software.php. Although, other feature detectors can also be used, e.g. SIFT, SURF etc.


Please write me an email if you find a problem with this code or if you 
have some possible improvements/suggestions:

williamliuxiang@gmail.com
