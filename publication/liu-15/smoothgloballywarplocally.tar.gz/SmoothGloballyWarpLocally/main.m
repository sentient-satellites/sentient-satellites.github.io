%% File 'main.m' runs everything and has 4 parts.
%
% 0.  Load in detected feature points: Here optic flow based feature
% tracker (N. Sundaram, T. Brox, K. Keutzer. Dense point trajectories by GPU-accelerated
% large displacement optical flow) is used. 
% However, most feature detectors can be used.
% 1.  Inter-frame homography: Estimate inter-frame homographies using
% detected feature points.
% 2.  Smooth globally: camera motion stabilization using 'Single Path
% Optimization'. Calculate the original camera motion chain and then optimize path C.
% 3.  Warp locally:  render output frames using homography fields.
%
%
% William Liu, Tat-Jun Chin  
% School of Computer Science
% The University of Adelaide
% South Australia
%
% February 2017

%% clear up a bit
close all;
clear;
clc

%% Setup library
addpath(genpath('lib'));
dataDir = 'data';

%% Load in feature points
disp('STEP 0: load in optical feature points');
load 'data/fpts';

% frame number
fnum = size(fpts,1)/2;

%% Inter-frame homography
disp('STEP 1: Inter-frame homography');
if exist('data/Hs.mat')
    % do nothing
else
    extractHs(dataDir);
end
load(fullfile(dataDir,'Hs.mat'));

%% Smooth using 'Single Path Opitmization'
disp('STEP 2: Smooth globally');
if exist('data/C_sp.mat') && exist('data/P_sp.mat')
    % do nothing
else
    % smooth
    smoothSinglepath;
end
load(fullfile(dataDir,'C_sp.mat'));
load(fullfile(dataDir,'P_sp.mat'));

%% Warp with homography field;
disp('STEP 3: Warp locally');
warpSinglepathMDLT;
warp2vid('warp_sp_mdlt');


